<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Cust extends Model
{
    use HasFactory;

    protected $table = 'cust';
    protected $primaryKey = 'no_id';
    public $timestamps = false;

    protected $fillable = 
    [
        "kodec", "namac", "alamat", "kota", "telpon1", "hp", "npwp", "ket", "na_pemilik", "fax", "golongan",
        "kontak", "email", "bank", "bank_cab", "bank_nama", "bank_kota", "bank_rek", "jenispjk", "lim", "hari"
    ];
}
