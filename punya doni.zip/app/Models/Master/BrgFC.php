<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


//ganti 1
class BrgFC extends Model
{
    use HasFactory;

// ganti 2
    protected $table = 'brgfc';
    protected $primaryKey = 'NO_ID';
    public $timestamps = false;

//ganti 3
    protected $fillable = 
    [
        "SUB", "KD_BRG", "NA_BRG", "KELOMPOK", "HB", "HJ", "TKP", "FLAGSTOK", "SUPP",
        "NAMAS", "BARCODE", "STAND", "LOK_TG", "TYPE", "MARGIN", "MARGIN2", "DIS", "HJ2"
    ];
}