<?php

namespace App\Models\Transaksi;

use Illuminate\Database\Eloquent\Model;

class KhususDetail extends Model
{
    protected $table = 'khususd';
    protected $primaryKey = 'NO_ID'; 
    public $timestamps = false;

    protected $fillable = [
        'no_bukti',
        'rec',
        'KD_BRG',
        'NA_BRG',
        'kodes',
        'ket_uk',
        'ket_kem',
        'qty',
        'lph',
        'SRMIN',
        'harga',
        'qtybrg',
        'qtypo',
        'notes',
        'per',
        'FLAG',
        'GOL',
    ];
}