<?php

namespace App\Models\Transaksi;

use Illuminate\Database\Eloquent\Model;

class Khusus extends Model
{
    protected $table = 'khusus';
    protected $primaryKey = 'NO_ID'; 
    public $timestamps = false;
    protected $fillable = [
        'no_bukti',
        'tgl',
        'per',
        'notes',
        'total_qty',
        'kodes',
        'namas',
        'usrnm',
        'flag',
        'GOL',
        'CBG',
        'HARI',
        'LPH1',
        'LPH2',
        'SUB1',
        'SUB2',
        'tg_smp'
    ];

}