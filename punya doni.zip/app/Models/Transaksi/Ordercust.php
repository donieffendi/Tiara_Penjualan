<?php

namespace App\Models\Transaksi;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


//ganti 1
class Ordercust extends Model
{
    use HasFactory;

// ganti 2
    protected $table = 'tpo';
    protected $primaryKey = 'NO_ID';
    public $timestamps = false;

//ganti 3
    protected $fillable = 
    [
        "no_bukti", "tgl", "per", "KET", "SUB", "KDBAR", "KD_BRG", "QTY",
		"usrnm", "KET_KEM", "tg_smp", "CBG", "NA_BRG", "flag", "notes", "rec"
    ];
}
