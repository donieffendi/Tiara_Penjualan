<?php

namespace App\Models\Transaksi;

use Illuminate\Database\Eloquent\Model;

class Po extends Model
{
    protected $table = 'po';
    protected $primaryKey = 'NO_ID'; 
    public $timestamps = false;
    protected $fillable = [
        'NO_BUKTI',
        'TGL',
        'PER',
        'NOTES',
        'TOTAL_QTY',
        'TOTAL',
        'NETT',
        'USRNM',
    ];

}