<?php

namespace App\Models\Transaksi;

use Illuminate\Database\Eloquent\Model;

class Pod extends Model
{
    protected $table = 'pod';
    protected $primaryKey = 'NO_ID'; 
    public $timestamps = false;

    protected $fillable = [
        'NO_BUKTI',
        'REC',
        'KD_BRG',
        'NA_BRG',
        'kemasan',
        'QTY',
        'HARGA',
        'TOTAL',
        'NOTES',
    ];
}