<?php

namespace App\Http\Controllers\OTransaksi;

use App\Http\Controllers\Controller;
// ganti 1

use App\Models\Transaksi\Ordercust;
use Illuminate\Http\Request;
use DataTables;
use Auth;
use DB;
use Carbon\Carbon;

include_once base_path() . "/vendor/simitgroup/phpjasperxml/version/1.1/PHPJasperXML.inc.php";
use PHPJasperXML;

// ganti 2
class OrdermanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
		
    public function index(Request $request)
    {
        // ganti 3
        return view('otransaksi_orderman.index');
    }
	

	public function index_posting(Request $request)
    {
 
        return view('otransaksi_orderman.post');
    }
	
	
    public function browse(Request $request)

    {
        $kd_brg = $request->KD_BRG;
        $brg = DB::SELECT("SELECT a.KD_BRG, a.NA_BRG, a.KET_KEM, b.GAK00 AS STOK FROM brg a, brgdt b WHERE a.KD_BRG = b.KD_BRG AND a.KD_BRG = '$kd_brg'");
        return response()->json($brg);

	}
    // ganti 4




    public function getOrderman(Request $request)
    {
        // ganti 5

       if ($request->session()->has('periode')) {
            $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
        } else {
            $periode = '';
        }
	
       $orderman = DB::SELECT("SELECT * FROM tpo WHERE flag = 'TM' AND PER='$periode' GROUP BY no_bukti ORDER BY no_bukti");
	  
	   
        // ganti 6

        return Datatables::of($orderman)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                if (Auth::user()->divisi=="programmer" ) 
				{
                    // url untuk delete di index
                    $url = "'".url("orderman/delete/" . $row->no_bukti )."'";
                    // batas

                    //CEK POSTED di index dan edit

                    $btnDelete = ' onclick="deleteRow('.$url.')"';

                    // $btnEdit =   ($row->POSTED == 1) ? ' onclick= "alert(\'Transaksi ' . $row->no_bukti . ' sudah diposting!\')" href="#" ' : ' href="ordercust/edit/?idx=' . $row->NO_ID . '&tipx=edit' . '"';					
                    // $btnDelete = ($row->POSTED == 1) ? ' onclick= "alert(\'Transaksi ' . $row->no_bukti . ' sudah diposting!\')" href="#" ' : ' onclick="return confirm(&quot; Apakah anda yakin ingin hapus? &quot;)" href="ordercust/delete/' . $row->NO_ID .'" ';


                    $btnPrivilege =
                        '
                                <a class="dropdown-item" href="orderman/edit/?idx=' . $row->NO_ID . '&tipx=edit&buktix=' .$row->no_bukti.'"; <i class="fas fa-edit"></i>
                                        Edit
                                    </a>
                                <a class="dropdown-item btn btn-danger" href="jsorderman/' . $row->NO_ID . '">
                                    <i class="fa fa-print" aria-hidden="true"></i>
                                    Print
                                </a> 									
                                <hr></hr>
                                <a class="dropdown-item btn btn-danger" ' . $btnDelete . '>
   
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    Delete
                                </a> 
                        ';
                } else {
                    $btnPrivilege = '';
                }

                $actionBtn =
                    '
                    <div class="dropdown show" style="text-align: center">
                        <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-bars"></i>
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            

                            ' . $btnPrivilege . '
                        </div>
                    </div>
                    ';

                return $actionBtn;
            })	
			
            ->rawColumns(['action'])
            ->make(true);
    }


//////////////////////////////////////////////////////////////////////////////////


			
			
			
			
///            ->rawColumns(['action'])
 //           ->make(true);
//    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $this->validate(
            $request,
            // GANTI 9

            [
                'tgl'      => 'required',
            ]
        );

        //////     nomer otomatis
		
        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $bulan    = session()->get('periode')['bulan'];
        $tahun    = substr(session()->get('periode')['tahun'], -2);

        $cbg = Auth::user()->CBG;

        switch ($cbg) {
            case 'TGZ':
                $suffix = 'Z';
                break;
            case 'TMM':
                $suffix = 'M';
                break;
            case 'SOP':
                $suffix = 'S';
                break;
            default:
                $suffix = '';
        }

        $query = DB::table('tpo')->select('no_bukti')->where('PER', $periode)->where('CBG', $cbg)->where('flag', 'TM')->orderByDesc('no_bukti')->limit(1)->get();

        if ($query != '[]') {
            $query    = $query[0]->no_bukti;
            $pecah    = explode('-', $query); // hasilnya ['B3 . per . bulan', 'query . CBG']
            $angka    = substr($pecah[1], 0, 4); // '0001'
            $query    = str_pad($angka + 1, 4, 0, STR_PAD_LEFT);
            $no_bukti = 'TM' . $tahun . $bulan . '-' . $query . $suffix;
        } else {
            $no_bukti = 'TM' . $tahun . $bulan . '-0001' . $suffix;
        }

        //////////////////////////////////////////////////////////////////////////
        $rec        = $request->input('rec');
		$KD_BRG	    = $request->input('KD_BRG');
		$NA_BRG	    = $request->input('NA_BRG');
		$KET_KEM	= $request->input('KET_KEM');
		$QTY	    = $request->input('QTY');

            if ($rec) {
                foreach ($rec as $key => $value) {

                    $SUB    = ($KD_BRG[$key] != null) ? substr($KD_BRG[$key], 0, 3) : '';
                    $KDBAR  = ($KD_BRG[$key] != null) ? substr($KD_BRG[$key], 3, 4) : '';

                    $orderman = Ordercust::create(
                        [
                            'no_bukti'         => $no_bukti,
                            'rec'              => $rec[$key],
                            'tgl'              => date('Y-m-d', strtotime($request['tgl'])),
                            'per'              => $periode,
                            'notes'            => ($request['notes'] == null) ? "" : $request['notes'],
                            'SUB'              => $SUB,
                            'KDBAR'            => $KDBAR,
                            'KD_BRG'           => ($KD_BRG[$key]==null) ? "" :  $KD_BRG[$key],
                            'QTY'              => (float) str_replace(',', '', $QTY[$key]),
                            'NA_BRG'           => ($NA_BRG[$key]==null) ? "" :  $NA_BRG[$key],
                            'KET_KEM'          => ($KET_KEM[$key]==null) ? "" :  $KET_KEM[$key],
                            'flag'             => 'TM',
                            'CBG'              => Auth::user()->CBG,
                            'usrnm'            => Auth::user()->username
                        ]
                    );	
                }
            }
        return redirect('/orderman')->with('statusInsert', 'Data baru berhasil ditambahkan');		
    }


    // ganti 15

   
   public function edit( Request $request , Ordercust $orderman)
    {


		$per = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];
		
				
        // $cekperid = DB::SELECT("SELECT POSTED from perid WHERE PERIO='$per'");
        // if ($cekperid[0]->POSTED==1)
        // {
        //     return redirect('/beliz')
		// 	       ->with('status', 'Maaf Periode sudah ditutup!')
        //            ->with(['judul' => $judul, 'flagz' => $FLAGZ, 'golz' => $GOLZ]);
        // }
		
        $tipx = $request->tipx;

		$idx = $request->idx;
			

		
		if ( $idx =='0' && $tipx=='undo'  )
	    {
			$tipx ='top';
			
		   }
		   
		 
		   
		if ($tipx=='search') {
			
		   	
    	   $buktix = $request->buktix;
		   
		   $bingco = DB::SELECT("SELECT NO_ID, no_bukti from tpo
		                 where PER ='$per'  
						 and no_bukti = '$buktix'						 
		                 ORDER BY no_bukti ASC  LIMIT 1" );
						 
			
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0; 
			  }
		
					
		}
		
		if ($tipx=='top') {
			

		   $bingco = DB::SELECT("SELECT NO_ID, no_bukti from tpo 
		                 where PER ='$per' 
		                 ORDER BY no_bukti ASC  LIMIT 1" );
						 
		
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0; 
			  }
		
					
		}
		
		
		if ($tipx=='prev' ) {
			
    	   $buktix = $request->buktix;
			
		   $bingco = DB::SELECT("SELECT NO_ID, no_bukti from tpo     
		             where PER ='$per' 
					 and no_bukti < 
					 '$buktix' ORDER BY no_bukti DESC LIMIT 1" );
			

			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = $idx; 
			  }
			  
		}
		
		
		if ($tipx=='next' ) {
			
				
      	   $buktix = $request->buktix;
	   
		   $bingco = DB::SELECT("SELECT NO_ID, no_bukti from tpo    
		            where PER ='$per'  
					and no_bukti > 
					'$buktix' ORDER BY no_bukti ASC LIMIT 1" );
					 
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = $idx; 
			  }
			  
			
		}

		if ($tipx=='bottom') {
		  
    		$bingco = DB::SELECT("SELECT NO_ID, no_bukti from tpo
						where PER ='$per'
		              ORDER BY no_bukti DESC  LIMIT 1" );
					 
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0; 
			  }
			  
			
		}

        
		if ( $tipx=='undo' || $tipx=='search' )
	    {
        
			$tipx ='edit';
			
		   }
		
		

       	if ( $idx != 0 ) 
		{   
            $buktix = $request->buktix;
			$orderman = Ordercust::where('no_bukti', $buktix )->get();	
	     }
		 else
		 {
				$orderman = [];
		 }

		$data = [
            'header'        => $orderman,
            'tipx'          => $tipx,
            'idx'           => $idx
        ];
         
        return view('otransaksi_orderman.edit', $data);
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Resbeliznse
     */

    // ganti 18

    public function update(Request $request, Ordercust $orderman)
    {

        $this->validate(
            $request,
            [
                'tgl'      => 'required',
            ]
        );
        // $variablell = DB::select('call belizdel(?)', array($beliz['NO_BUKTI']));
        
        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

		$length = sizeof($request->input('rec'));
        $NO_ID  = $request->input('NO_ID');

        $rec    = $request->input('rec');

        $KD_BRG	    = $request->input('KD_BRG');
        $NA_BRG	    = $request->input('NA_BRG');
		$KET_KEM	= $request->input('KET_KEM');
		$QTY	    = $request->input('QTY');	

        $query = DB::table('tpo')->where('no_bukti', $request->no_bukti)->whereNotIn('NO_ID',  $NO_ID)->delete();

        // Update / Insert
        for ($i = 0; $i < $length; $i++) {

            $SUB    = ($KD_BRG[$i] != null) ? substr($KD_BRG[$i], 0, 3) : '';
            $KDBAR  = ($KD_BRG[$i] != null) ? substr($KD_BRG[$i], 3, 4) : '';
            
            // Insert jika NO_ID baru
            if ($NO_ID[$i] == 'new') {
                $insert = Ordercust::create(
                    [
                        'no_bukti'         => $request->no_bukti,
                        'rec'              => $rec[$i],
                        'tgl'              => date('Y-m-d', strtotime($request['tgl'])),
                        'per'              => $periode,
                        'notes'            => ($request['notes'] == null) ? "" : $request['notes'],
                        'SUB'              => $SUB,
                        'KDBAR'            => $KDBAR,
                        'KD_BRG'           => ($KD_BRG[$i]==null) ? "" :  $KD_BRG[$i],
                        'NA_BRG'           => ($NA_BRG[$i]==null) ? "" :  $NA_BRG[$i],
                        'KET_KEM'          => ($KET_KEM[$i]==null) ? "" :  $KET_KEM[$i],
                        'QTY'              => (float) str_replace(',', '', $QTY[$i]),
                        'flag'             => 'TM',
                        'CBG'              => Auth::user()->CBG,
                        'usrnm'            => Auth::user()->username
                    ]
                );
            } else {
                // Update jika NO_ID sudah ada
                $upsert = Ordercust::updateOrCreate(
                    [
                        'no_bukti'  => $request->no_bukti,
                        'NO_ID'     => (int) str_replace(',', '', $NO_ID[$i])
                    ],

                    [
                        'rec'        => $rec[$i],

                        'SUB'              => $SUB,
                        'KDBAR'            => $KDBAR,
                        'KD_BRG'           => ($KD_BRG[$i]==null) ? "" :  $KD_BRG[$i],
                        'NA_BRG'           => ($NA_BRG[$i]==null) ? "" :  $NA_BRG[$i],
                        'KET_KEM'          => ($KET_KEM[$i]==null) ? "" :  $KET_KEM[$i],
                        'QTY'              => (float) str_replace(',', '', $QTY[$i]),						
                    ]
                );
            }
        }

		return redirect('/orderman')->with('status', 'Data baru berhasil diedit');
	   
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Resbeliznse
     */

    // ganti 22

    public function destroy($no_bukti)
    {
        $deleted = \App\Models\Transaksi\Ordercust::where('no_bukti', $no_bukti)->delete();

        if ($deleted > 0) {
            return redirect('/orderman')->with('status', "Data dengan No. Bukti $no_bukti berhasil dihapus ($deleted baris)");
        } else {
            return redirect('/orderman')->with('status', "Data dengan No. Bukti $no_bukti tidak ditemukan");
        }
    }
}
