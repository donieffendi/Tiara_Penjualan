<?php

namespace App\Http\Controllers\OTransaksi;

use App\Http\Controllers\Controller;
// ganti 1

use App\Models\Transaksi\Khusus;
use App\Models\Transaksi\KhususDetail;
use App\Models\Master\Sup;
use Illuminate\Http\Request;
use DataTables;
use Auth;
use DB;
use Carbon\Carbon;

include_once base_path() . "/vendor/simitgroup/phpjasperxml/version/1.1/PHPJasperXML.inc.php";
use PHPJasperXML;

// ganti 2
class OrderpjlController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    var $judul = '';
    var $FLAGZ = '';

    function setFlag(Request $request)
    {

        if ( $request->flagz == 'BL') {
            $this->judul = "Rencana Order Penjualan";
        } else {
            $this->judul = "";
        }

        $this->FLAGZ = $request->flagz;
    }

    public function index(Request $request)
    {

	    $this->setFlag($request);

        if ($this->FLAGZ == 'BL') {
            $view = "otransaksi_orderpjl.index";
        } else {
            $view = "otransaksi_orderpbl.index_posting";
        }
        return view($view)->with([
            'judul' => $this->judul,
            'flagz' => $this->FLAGZ
        ]);
    }

	public function browse(Request $request)
    {
        $filterkodes = "";
        $filterlph   = "";
        $filtersub   = "";

        if (!empty($request->kodes) && !empty($request->kodes2))
			{
				$filterkodes = " and c.KODES between '".$request->kodes."' and '".$request->kodes2."' ";
			}
        
        if (!empty($request->LPH1) && !empty($request->LPH2))
			{
				$filterlph = " and b.LPH between '".$request->LPH1."' and '".$request->LPH2."' ";
			}

        if (!empty($request->SUB1) && !empty($request->SUB2))
			{
				$filtersub = " and a.SUB between '".$request->SUB1."' and '".$request->SUB2."' ";
			}

        $orderpjl = DB::SELECT("SELECT c.KODES AS kodes, c.NAMAS as namas, a.KD_BRG, a.NA_BRG, a.KET_UK as ket_uk, a.KET_KEM as ket_kem,
                                b.LPH as lph, b.HJ AS harga
                        FROM brg a, brgdt b, sup c 
                        WHERE a.KD_BRG = b.KD_BRG 
                        AND a.SUPP = c.KODES
                        $filterkodes
                        $filterlph
                        $filtersub");

        return response()->json($orderpjl);
    }

	public function index_posting(Request $request)
    {

        return view('otransaksi_po.post');
    }
    // ganti 4



    public function getOrderpjl(Request $request)
    {
        // ganti 5

        $periode = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];
		
        $this->setFlag($request);
        $FLAGZ = $this->FLAGZ;
        $judul = $this->judul;

        $CBG = Auth::user()->CBG;

        $orderpjl = DB::SELECT("SELECT NO_ID, no_bukti, tgl, total_qty, notes, posted, flag
                            FROM `khusus` WHERE flag = '$FLAGZ' AND PER='$periode' ORDER BY no_bukti");


        // ganti 6

        return Datatables::of($orderpjl)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                if (Auth::user()->divisi=="programmer" )
				{
                    //CEK POSTED di index dan edit

                    // url untuk delete di index
                    $url = "'".url("orderpjl/delete/" . $row->NO_ID . "/?flagz=" . $row->flag)."'";
                    // batas

                    $btnEdit =   ($row->posted == 1) ? ' onclick= "alert(\'Transaksi ' . $row->NO_BUKTI . ' sudah diposting!\')" href="#" ' : ' href="orderpjl/edit/?idx=' . $row->NO_ID . '&tipx=edit&flagz=' . $row->flag . '&judul=' . $this->judul . '"';
                    $btnDelete = ($row->posted == 1) ? ' onclick= "alert(\'Transaksi ' . $row->NO_BUKTI . ' sudah diposting!\')" href="#" ' : ' onclick="deleteRow('.$url.')"';


                    $btnPrivilege =
                        '
                                <a class="dropdown-item" ' . $btnEdit . '>
                                <i class="fas fa-edit"></i>
                                    Edit
                                </a>
                                <a class="dropdown-item btn btn-danger" href="orderpbl/cetak/' . $row->NO_ID . '">
                                    <i class="fa fa-print" aria-hidden="true"></i>
                                    Print
                                </a>
                                <hr></hr>
                                <a class="dropdown-item btn btn-danger" ' . $btnDelete . '>

                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    Delete
                                </a>
                        ';
                } else {
                    $btnPrivilege = '';
                }

                $actionBtn =
                    '
                    <div class="dropdown show" style="text-align: center">
                        <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-bars"></i>
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">


                            ' . $btnPrivilege . '
                        </div>
                    </div>
                    ';

                return $actionBtn;
            })

            ->rawColumns(['action'])
            ->make(true);
    }

//////////////////////////////////////////////////////////////////////////////////

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $this->validate(
            $request,
            // GANTI 9

            [
                'no_bukti'      => 'required'
            ]
        );

        //////     nomer otomatis
		$this->setFlag($request);
        $FLAGZ = $this->FLAGZ;
        $judul = $this->judul;

        $CBG = Auth::user()->CBG;

        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $bulan    = session()->get('periode')['bulan'];
        $tahun    = substr(session()->get('periode')['tahun'], -2);

        $query = DB::table('khusus')->select('no_bukti')->where('per', $periode)->where('flag', 'BL')->where('CBG', $CBG)
                ->orderByDesc('no_bukti')->limit(1)->get();

            if ($query != '[]') {
                $query = substr($query[0]->no_bukti, -5);
                $query = str_pad($query + 1, 5, 0, STR_PAD_LEFT);
                $no_bukti = 'BL' . $bulan . $tahun . '-' .  $query;
            } else {
                $no_bukti = 'BL' . $bulan . $tahun .  '-00001';
            }
        
        $orderpjl = Khusus::create(
            [
                'no_bukti'         => $no_bukti,
                'per'              => $periode,
                'tgl'              => date('Y-m-d', strtotime($request['tgl'])),
                'notes'            => ($request['notes'] == null) ? "" : $request['notes'],
				'kodes'            => ($request['kodes'] == null) ? "" : $request['kodes'],
                'namas'            => ($request['namas'] == null) ? "" : $request['namas'],
                'LPH1'             => (float) str_replace(',', '', $request['LPH1']),
                'LPH2'             => (float) str_replace(',', '', $request['LPH2']),
                'HARI'             => (float) str_replace(',', '', $request['HARI']),
                'SUB1'             => ($request['SUB1'] == null) ? "" : $request['SUB1'],
                'SUB2'             => ($request['SUB2'] == null) ? "" : $request['SUB2'],
                'total_qty'        => (float) str_replace(',', '', $request['ttotal_qty']),
                'flag'             => $FLAGZ,
                'CBG'              => $CBG,
                'usrnm'            => Auth::user()->username,
                'tg_smp'           => Carbon::now(),
            ]
        );


		$rec        = $request->input('rec');
        $kodesd     = $request->input('kodesd');
		$KD_BRG     = $request->input('KD_BRG');
        $NA_BRG     = $request->input('NA_BRG');
        $ket_uk     = $request->input('ket_uk');
        $ket_kem    = $request->input('ket_kem');
        $qty        = $request->input('qty');
        $lph        = $request->input('lph');
        $qtybrg     = $request->input('qtybrg');
        $qtypo      = $request->input('qtypo');
        $harga      = $request->input('harga');
        $TOTAL      = $request->input('TOTAL');
        $notes      = $request->input('notesd');

        // Check jika value detail ada/tidak
        if ($rec) {
            foreach ($rec as $key => $value) {
                // Declare new data di Model
                $detail    = new KhususDetail;

                // Insert ke Database
                $detail->no_bukti    = $no_bukti;
                $detail->rec         = $rec[$key];
                $detail->per         = $periode;
                $detail->flag        = $FLAGZ;
                $detail->CBG         = $CBG;
                $detail->kodes       = ($kodesd[$key] == null) ? "" :  $kodesd[$key];
                $detail->KD_BRG      = ($KD_BRG[$key] == null) ? "" :  $KD_BRG[$key];
                $detail->NA_BRG      = ($NA_BRG[$key] == null) ? "" :  $NA_BRG[$key];
                $detail->ket_uk      = ($ket_uk[$key] == null) ? "" :  $ket_uk[$key];
                $detail->ket_kem     = ($ket_kem[$key] == null) ? "" :  $ket_kem[$key];
                $detail->qty         = (float) str_replace(',', '', $qty[$key]);
                $detail->lph         = (float) str_replace(',', '', $lph[$key]);
                $detail->qtybrg      = (float) str_replace(',', '', $qtybrg[$key]);
                $detail->qtypo       = (float) str_replace(',', '', $qtypo[$key]);
                $detail->harga       = (float) str_replace(',', '', $harga[$key]);
                $detail->TOTAL       = (float) str_replace(',', '', $TOTAL[$key]);
                $detail->notes       = ($notes[$key] == null) ? "" :  $notes[$key];
                $detail->save();
            }
        }

		$no_buktix = $no_bukti;

		$orderpjl = Khusus::where('no_bukti', $no_buktix )->first();

        DB::SELECT("UPDATE khusus,  khususd
                            SET  khususd.ID =  khusus.NO_ID  WHERE  khusus.no_bukti =  khususd.no_bukti
							AND  khusus.no_bukti='$no_buktix';");



        // return redirect('/po/edit/?idx=' . $po->NO_ID . '&tipx=edit&flagz=' . $this->FLAGZ . '&golz=' . $this->GOLZ . '&judul=' . $this->judul . '');
        return redirect('/orderpjl?flagz='.$FLAGZ)->with(['judul' => $judul, 'flagz' => $FLAGZ]);

    }

    public function edit( Request $request , Khusus $orderpjl)
    {


		$per = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];


        // $cekperid = DB::SELECT("SELECT POSTED from perid WHERE PERIO='$per'");
        // if ($cekperid[0]->POSTED==1)
        // {
        //     return redirect('/po')
		// 	       ->with('status', 'Maaf Periode sudah ditutup!')
        //            ->with(['judul' => $judul, 'flagz' => $FLAGZ]);
        // }

		$this->setFlag($request);

        $tipx = $request->tipx;

		$idx = $request->idx;

        $CBG = Auth::user()->CBG;

		if ( $idx =='0' && $tipx=='undo'  )
	    {
			$tipx ='top';

		   }



		if ($tipx=='search') {


    	   $buktix = $request->buktix;

		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from khusus
		                 where PER ='$per' and FLAG ='$this->FLAGZ'
                         AND CBG = '$CBG'
						 and NO_BUKTI = '$buktix'
		                 ORDER BY NO_BUKTI ASC  LIMIT 1" );


			if(!empty($bingco))
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0;
			  }


		}

		if ($tipx=='top') {


		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from khusus
		                 where PER ='$per'
						 and FLAG ='$this->FLAGZ'
                         AND CBG = '$CBG'
		                 ORDER BY NO_BUKTI ASC  LIMIT 1" );


			if(!empty($bingco))
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0;
			  }


		}


		if ($tipx=='prev' ) {

    	   $buktix = $request->buktix;

		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from khusus
		             where PER ='$per'
					 and FLAG ='$this->FLAGZ'
                     AND CBG = '$CBG'
                     and NO_BUKTI <
					 '$buktix' ORDER BY NO_BUKTI DESC LIMIT 1" );


			if(!empty($bingco))
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = $idx;
			  }

		}


		if ($tipx=='next' ) {


      	   $buktix = $request->buktix;

		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from khusus
		             where PER ='$per'
					 and FLAG ='$this->FLAGZ'
                     AND CBG = '$CBG'
                     and NO_BUKTI >
					 '$buktix' ORDER BY NO_BUKTI ASC LIMIT 1" );

			if(!empty($bingco))
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = $idx;
			  }


		}

		if ($tipx=='bottom') {

    		$bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from khusus
						where PER ='$per'
						and FLAG ='$this->FLAGZ'
                        AND CBG = '$CBG'
		                ORDER BY NO_BUKTI DESC  LIMIT 1" );

			if(!empty($bingco))
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0;
			  }


		}


		if ( $tipx=='undo' || $tipx=='search' )
	    {

			$tipx ='edit';

		   }



       	if ( $idx != 0 )
		{
			$orderpjl = Khusus::where('NO_ID', $idx )->first();
	     }
		 else
		 {
				$orderpjl = new Khusus;
                $orderpjl->tgl = Carbon::now();


		 }

        $no_bukti = $orderpjl->no_bukti;
        $orderpjlDetail = DB::table('khususd')->where('no_bukti', $no_bukti)->orderBy('rec')->get();

		$data = [
            'header'        => $orderpjl,
			'detail'        => $orderpjlDetail

        ];

 		$sup = DB::SELECT("SELECT KODES, CONCAT(NAMAS,'-',KOTA) AS NAMAS FROM SUP
		                 ORDER BY NAMAS ASC" );


         return view('otransaksi_orderpjl.edit', $data)->with(['sup' => $sup])
		 ->with(['tipx' => $tipx, 'idx' => $idx, 'flagz' => $this->FLAGZ, 'judul'=> $this->judul ]);


    }

  /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 18

    public function update(Request $request, Khusus $orderpjl)
    {

        $this->validate(
            $request,
            [

                'no_bukti'      => 'required'
            ]
        );

		$this->setFlag($request);
        $FLAGZ = $this->FLAGZ;
        $judul = $this->judul;

        $CBG = Auth::user()->CBG;


        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $orderpjl->update(
            [
                'tgl'              => date('Y-m-d', strtotime($request['tgl'])),
                'kodes'            => ($request['kodes'] == null) ? "" : $request['kodes'],
                'namas'            => ($request['namas'] == null) ? "" : $request['namas'],
                'notes'            => ($request['notes'] == null) ? "" : $request['notes'],
                'HARI'             => (float) str_replace(',', '', $request['HARI']),
				'usrnm'            => Auth::user()->username,
                'tgsmp'            => Carbon::now(),
            ]
        );
        
		$no_buktix = $orderpjl->no_bukti;

        // Update Detail
        $length = sizeof($request->input('rec'));
        $NO_ID  = $request->input('NO_ID');

        $rec     = $request->input('rec');
        $kodesd     = $request->input('kodesd');
		$KD_BRG     = $request->input('KD_BRG');
        $NA_BRG     = $request->input('NA_BRG');
        $ket_uk     = $request->input('ket_uk');
        $ket_kem    = $request->input('ket_kem');
        $qty        = $request->input('qty');
        $lph        = $request->input('lph');
        $qtybrg     = $request->input('qtybrg');
        $qtypo      = $request->input('qtypo');
        $harga      = $request->input('harga');
        $TOTAL      = $request->input('TOTAL');
        $notes      = $request->input('notesd');

        $query = DB::table('khususd')->where('no_bukti', $request->no_bukti)->whereNotIn('NO_ID',  $NO_ID)->delete();

        // Update / Insert
        for ($i = 0; $i < $length; $i++) {
            // Insert jika NO_ID baru
            if ($NO_ID[$i] == 'new') {
                $insert = KhususDetail::create(
                    [
                        'no_bukti'   => $request->no_bukti,
                        'rec'        => $rec[$i],
                        'per'        => $periode,
                        'FLAG'       => $this->FLAGZ,
                        'GOL'        => $this->GOLZ,
                        'KD_BRG'     => ($KD_BRG[$i] == null) ? "" :  $KD_BRG[$i],
                        'NA_BRG'     => ($NA_BRG[$i] == null) ? "" :  $NA_BRG[$i],
                        'ket_uk'     => ($ket_uk[$i] == null) ? "" :  $ket_uk[$i],
                        'ket_kem'    => ($ket_kem[$i] == null) ? "" :  $ket_kem[$i],
                        'qty'        => (float) str_replace(',', '', $qty[$i]),
                        'lph'        => (float) str_replace(',', '', $lph[$i]),
                        'qtybrg'     => (float) str_replace(',', '', $qtybrg[$i]),
                        'qtypo'      => (float) str_replace(',', '', $qtypo[$i]),
                        'harga'      => (float) str_replace(',', '', $harga[$i]),
                        'TOTAL'      => (float) str_replace(',', '', $TOTAL[$i]),
                        'notes'      => ($notes[$i] == null) ? "" :  $notes[$i],
                    ]
                );
            } else {
                // Update jika NO_ID sudah ada
                $upsert = KhususDetail::updateOrCreate(
                    [
                        'no_bukti'  => $request->no_bukti,
                        'NO_ID'     => (int) str_replace(',', '', $NO_ID[$i])
                    ],

                    [
                        'rec'        => $rec[$i],

                        'KD_BRG'     => ($KD_BRG[$i] == null) ? "" :  $KD_BRG[$i],
                        'NA_BRG'     => ($NA_BRG[$i] == null) ? "" :  $NA_BRG[$i],
                        'ket_uk'     => ($ket_uk[$i] == null) ? "" :  $ket_uk[$i],
                        'ket_kem'    => ($ket_kem[$i] == null) ? "" :  $ket_kem[$i],
                        'qty'        => (float) str_replace(',', '', $qty[$i]),
                        'lph'        => (float) str_replace(',', '', $lph[$i]),
                        'qtybrg'     => (float) str_replace(',', '', $qtybrg[$i]),
                        'qtypo'      => (float) str_replace(',', '', $qtypo[$i]),
                        'harga'      => (float) str_replace(',', '', $harga[$i]),
                        'TOTAL'      => (float) str_replace(',', '', $TOTAL[$i]),
                        'notes'      => ($notes[$i] == null) ? "" :  $notes[$i]
                    ]
                );
            }
        }

 		$orderpjl= Khusus::where('no_bukti', $no_buktix )->first();
        if (!$orderpjl) {
            return back()->withErrors(['Data Rencana Order Penjualan dengan Bukti ' . $no_buktix . ' tidak ditemukan.']);
        }
        
        $no_bukti = $orderpjl->no_bukti;

        DB::SELECT("UPDATE khusus,  khususd
                    SET  khususd.ID =  khusus.NO_ID  WHERE  khusus.no_bukti =  khususd.no_bukti
                    AND  khusus.no_bukti='$no_bukti';");

        // return redirect('/po/edit/?idx=' . $po->NO_ID . '&tipx=edit&flagz=' . $this->FLAGZ . '&golz=' . $this->GOLZ . '&judul=' . $this->judul . '');
        return redirect('/orderpbl?flagz='.$FLAGZ)->with(['judul' => $judul, 'flagz' => $FLAGZ ]);


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 22

    public function destroy(Request $request, Khusus $orderpjl)
    {

		$this->setFlag($request);
        $FLAGZ = $this->FLAGZ;
        $judul = $this->judul;

        // ini dr mana $this->GOLZ?
        $FLAGZ = $_GET['flagz'];

		$per = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];
        $cekperid = DB::SELECT("SELECT posted from perid WHERE PERIO='$per'");
        if ($cekperid[0]->posted==1)
        {
            return redirect()->route('khusus')
                ->with('status', 'Maaf Periode sudah ditutup!')
                ->with(['judul' => $this->judul, 'flagz' => $this->FLAGZ]);
        }

        KhususDetail::where('no_bukti', $orderpjl->no_bukti)->delete();
        $deleteOrderpbl = Khusus::find($orderpjl->NO_ID);

        $deleteOrderpbl->delete();
        // return redirect('/po?flagz=' . $FLAGZ . '&golz=J')
        return redirect('/orderpbl?flagz='. $FLAGZ)
        ->with(['judul' => $judul, 'flagz' => $this->FLAGZ])
        ->with('statusHapus', 'Data ' . $orderpjl->no_bukti . ' berhasil dihapus');





    }

    public function cetak(Po $po)
    {
        $no_po = $po->NO_BUKTI;

        $file     = 'poc';
        $PHPJasperXML = new PHPJasperXML();
        $PHPJasperXML->load_xml_file(base_path() . ('/app/reportc01/phpjasperxml/' . $file . '.jrxml'));

        //po.GUDANG setelah po.NETT dihapus
        $query = DB::SELECT("SELECT po.NO_BUKTI, po.TGL, po.KODES, po.NAMAS, po.TOTAL_QTY, po.NOTES, po.ALAMAT,
                                    po.KOTA, pod.KD_BRG, pod.NA_BRG, pod.SATUAN, pod.QTY,
                                    pod.HARGA, pod.TOTAL, pod.KET, po.TPPN, po.NETT,
                                    po.JTEMPO, po.TDPP, po.TDISK, pod.DISK
                            FROM po, pod
                            WHERE po.NO_BUKTI='$no_po' AND po.NO_BUKTI = pod.NO_BUKTI
                            ;
		");


        $data = [];

        foreach ($query as $key => $value) {
            array_push($data, array(
                'NO_BUKTI' => $query[$key]->NO_BUKTI,
                'TGL'      => $query[$key]->TGL,
                'JTEMPO'      => $query[$key]->JTEMPO,
                'KODES'    => $query[$key]->KODES,
                'NAMAS'    => $query[$key]->NAMAS,
                'ALAMAT'    => $query[$key]->ALAMAT,
                'KOTA'    => $query[$key]->KOTA,
                'KG'       => $query[$key]->KG,
                'HARGA'    => $query[$key]->HARGA,
                'TOTAL'    => $query[$key]->TOTAL,
                'BAYAR'    => $query[$key]->BAYAR,
                'NOTES'    => $query[$key]->NOTES,
                // 'KD_BRG'    => "`".strval($query[$key]->KD_BRG),
                'KD_BRG'    => $query[$key]->KD_BRG,
                'NA_BRG'    => $query[$key]->NA_BRG,
                'SATUAN'    => $query[$key]->SATUAN,
                'QTY'    => $query[$key]->QTY,
                'PPN'    => $query[$key]->TPPN,
                'NETT'    => $query[$key]->NETT,
                'TDPP'    => $query[$key]->TDPP,
                'TDISK'    => $query[$key]->TDISK,
                'DISK'    => $query[$key]->DISK,
                'KET'    => $query[$key]->KET,
                // 'GUDANG'    => $query[$key]->GUDANG
            ));
        }

        $PHPJasperXML->setData($data);
        ob_end_clean();
        $PHPJasperXML->outpage("I");

        DB::SELECT("UPDATE PO SET POSTED = 1 WHERE PO.NO_BUKTI='$no_po';");

    }



	 public function posting(Request $request)
    {

        $CEK = $request->input('cek');
        $NO_BUKTI = $request->input('NO_BUKTI');

        $usrnmx = Auth::user()->username;

        $hasil = "";

        if ($CEK) {
            foreach ($CEK as $key => $value)
			{

                    //$STA = $request->input('STA');

					$periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
					$bulan    = session()->get('periode')['bulan'];
					$tahun    = substr(session()->get('periode')['tahun'], -2);

			   $NO_BUKTIXZ  = $NO_BUKTI[$key];


                    DB::SELECT("UPDATE PO SET POSTED = 1 WHERE PO.NO_BUKTI='$NO_BUKTIXZ'");

			}
		}
		else
		{
			$hasil = $hasil ."Tidak ada PO yang dipilih! ; ";
		}

					if($hasil!='')
					{
						return redirect('/po/index-posting')->with('status', 'Proses Posting PO ..')->with('gagal', $hasil);
					}
					else
					{
						return redirect('/po/index-posting')->with('status', 'Posting Posting PO selesai..');
					}







    }


	public function jtempo ( Request $request)
    {
		$tgl = $request->input('TGL');
		$hari = substr($tgl,0,2);
		$bulan = substr($tgl,3,2);
		$tahun = substr($tgl,6,4);
		$harix = $request->HARI;

		$datex = Carbon::createFromDate($tahun, $bulan, $hari );

        $datex ->addDays($harix);

        $datey = $datex->format('d-m-Y');
		return  $datey;


	}

	public function getDetailPo(){

        $no_bukti = $_GET['no_bukti'];
        $result = DB::table('pod')->where('NO_BUKTI', $no_bukti)->get();

        return response()->json($result);;
    }

    public function posting_po(Request $request)
    {
        if (! $request->isMethod('post')) {
            return response()->json(['error' => 'Method Not Allowed'], 405);
        }

        $data = $request->input('posted');

        if (! $data) {
            return response()->json(['error' => 'Tidak ada data yang dikirim'], 400);
        }

        foreach ($data as $id => $posted) {
            DB::table('po')->where('NO_ID', $id)->update(['POSTED' => $posted]);
        }

        return response()->json(['message' => 'Status berhasil diperbarui']);
    }

    public function posting_pc(Request $request)
    {
        if (! $request->isMethod('post')) {
            return response()->json(['error' => 'Method Not Allowed'], 405);
        }

        $data = $request->input('posted');

        if (! $data) {
            return response()->json(['error' => 'Tidak ada data yang dikirim'], 400);
        }

        foreach ($data as $id => $posted) {
            DB::table('po')->where('NO_ID', $id)->update(['POSTED' => $posted]);
        }

        return response()->json(['message' => 'Status berhasil diperbarui']);
    }

}
