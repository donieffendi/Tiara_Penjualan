<?php

namespace App\Http\Controllers\OTransaksi;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\Master\Brg;
use App\Models\Master\Sup;
use DataTables;
use Auth;
use DB;

class Ordkode8Controller extends Controller
{

    public function index() {
        return view('otransaksi_ordkode8.index');
    }

    public function getOrdkode8(Request $request)
    {
        $ke = $request->KE ?: '';         // parameter ke-3
        $cbg = Auth::user()->CBG ?: '';   // parameter ke-4

        // Panggil SP dengan 5 parameter yang pasti ada
        $sql = DB::select("CALL pjl_ord_toko_kode8(?, ?, ?, ?, ?)", ['TAMPIL', '', $ke, $cbg, '']);

        return Datatables::of($sql)
            ->addIndexColumn()
            ->make(true);
    }



}