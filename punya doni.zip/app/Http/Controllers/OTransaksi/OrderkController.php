<?php
namespace App\Http\Controllers\OTransaksi;

use App\Http\Controllers\Controller;
// ganti 1

use App\Models\OTransaksi\Orderk;
use App\Models\OTransaksi\OrderkDetail;
use Auth;
use Carbon\Carbon;
use DataTables;
use DB;
use Illuminate\Http\Request;

include_once base_path() . "/vendor/simitgroup/phpjasperxml/version/1.1/PHPJasperXML.inc.php";
use PHPJasperXML;

// ganti 2
class OrderkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Resbelinse
     */
    public $judul = '';
    public $FLAGZ = '';
    public $GOLZ  = '';

    public function setFlag(Request $request)
    {
        if ($request->flagz == 'OK' && $request->golz == 'J') {
            $this->judul = "Order Kerja";
        } else if ($request->flagz == '' && $request->golz == '') {
            $this->judul = "";
        }

        $this->FLAGZ = $request->flagz;
        $this->GOLZ  = $request->golz;

    }

    public function index(Request $request)
    {

        $this->setFlag($request);
        // ganti 3
        return view('otransaksi_orderk.index')->with(['judul' => $this->judul, 'flagz' => $this->FLAGZ, 'golz' => $this->GOLZ]);

    }

    public function browseCust(Request $request)
    {
        // $golz = $request->GOL;

        $so = DB::SELECT("SELECT KODEC,NAMAC,ALAMAT,KOTA from cust where AKT ='1' order by KODEC");
        return response()->json($so);
    }

    public function browseSo(Request $request)
    {
        $golz = $request->GOL;

        $CBG = Auth::user()->CBG;

        $so = DB::SELECT("SELECT sod.NO_ID, so.NO_BUKTI, so.TGL, so.KODEC, so.NAMAC, so.ALAMAT, so.KOTA, so.TOTAL_QTY AS QTY, sod.KD_BRG, sod.NA_BRG, sod.SATUAN,
                                sod.SISA from so, sod
                        WHERE so.NO_BUKTI=sod.NO_BUKTI and sod.SISA>0
                        AND so.GOL ='$golz'
                        AND so.CBG = '$CBG' ");
        return response()->json($so);
    }

    public function browse_detail(Request $request)
    {

        // $filterbukti = '';
        // if($request->NO_SO)
        // {

        //     $filterbukti = " WHERE NO_BUKTI='".$request->NO_SO."' ";
        // }
        $sod = DB::SELECT("SELECT REC, KD_BRG, NA_BRG, SATUAN , QTY AS QTY_SO, HARGA, KIRIM, SISA, TOTAL, KET, '0' AS QTY, '' AS NO_FO
                            from sod
                            where NO_BUKTI='" . $request->nobukti . "' ORDER BY NO_BUKTI ");

        return response()->json($sod);
    }

    public function browseFo(Request $request)
    {
        $fo = DB::SELECT("SELECT a.NO_BUKTI, a.KD_BRG, a.NA_BRG, a.TOTAL_QTY from fo a where a.KD_BRG='" . $request->kdbrg . "' order by a.NO_BUKTI");
        // $fo = DB::SELECT("SELECT a.NO_BUKTI, a.KD_BRG, a.NA_BRG, a.TOTAL_QTY AS QTY from fo a  order by a.NO_BUKTI");
        return response()->json($fo);
    }

    public function browseFodPrs(Request $request)
    {
        $fod = DB::SELECT("SELECT REC, KD_PRS, NA_PRS, KD_BHN, NA_BHN, SATUAN, QTY, KET from fod where NO_BUKTI='" . $request->NO_FO . "' and KD_PRS ='" . $request->KD_PRSH . "' order by REC");
        return response()->json($fod);
    }

    public function browse_detail2(Request $request)
    {
        $filterbukti = '';
        if ($request->NO_PO) {

            $filterbukti = " WHERE NO_BUKTI='" . $request->NO_PO . "' AND a.KD_BRG = b.KD_BRG ";
        }

        $orderkd = DB::SELECT("SELECT a.REC, a.KD_BRG, a.NA_BRG, a.SATUAN , a.QTY, a.HARGA, a.KIRIM, a.SISA,
                                b.SATUAN AS SATUAN_PO, a.QTY AS QTY_PO, '1' AS X
                            from orderkd a, brg b
                            $filterbukti ORDER BY NO_BUKTI ");

        return resorderknse()->json($orderkd);
    }
    // ganti 4

    public function getOrderk(Request $request)
    {
        // ganti 5

        if ($request->session()->has('periode')) {
            $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
        } else {
            $periode = '';
        }

        $this->setFlag($request);
        $FLAGZ = $this->FLAGZ;
        $GOLZ  = $this->GOLZ;
        $judul = $this->judul;

        $CBG = Auth::user()->CBG;

        $orderk = DB::SELECT("SELECT * from orderk WHERE PER='$periode' and FLAG ='$this->FLAGZ'
                            and GOL ='$this->GOLZ' AND CBG = '$CBG' ORDER BY NO_BUKTI ");

        // ganti 6

        return Datatables::of($orderk)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                if (Auth::user()->divisi == "programmer") {
                    //CEK POSTED di index dan edit

                    $btnEdit   = ($row->POSTED == 1) ? ' onclick= "alert(\'Transaksi ' . $row->NO_BUKTI . ' sudah diorderksting!\')" href="#" ' : ' href="orderk/edit/?idx=' . $row->NO_ID . '&tipx=edit&flagz=' . $row->FLAG . '&judul=' . $this->judul . '&golz=' . $row->GOL . '"';
                    $btnDelete = ($row->POSTED == 1) ? ' onclick= "alert(\'Transaksi ' . $row->NO_BUKTI . ' sudah diorderksting!\')" href="#" ' : ' onclick="return confirm(&quot; Apakah anda yakin ingin hapus? &quot;)" href="orderk/delete/' . $row->NO_ID . '/?flagz=' . $row->FLAG . '&golz=' . $row->GOL . '" ';

                    $btnPrivilege =
                    '
                                <a class="dropdown-item" ' . $btnEdit . '>
                                <i class="fas fa-edit"></i>
                                    Edit
                                </a>
                                <a class="dropdown-item btn btn-danger" href="cetak/' . $row->NO_ID . '">
                                    <i class="fa fa-print" aria-hidden="true"></i>
                                    Print
                                </a>
                                <hr></hr>
                                <a class="dropdown-item btn btn-danger" ' . $btnDelete . '>

                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    Delete
                                </a>
                        ';
                } else {
                    $btnPrivilege = '';
                }

                $actionBtn =
                    '
                    <div class="dropdown show" style="text-align: center">
                        <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-hasorderkpup="true" aria-expanded="false">
                            <i class="fas fa-bars"></i>
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">


                            ' . $btnPrivilege . '
                        </div>
                    </div>
                    ';

                return $actionBtn;
            })

            ->addColumn('cek', function ($row) {
                return;
                '
                    <input type="checkbox" name="cek[]" class="form-control cek" ' . (($row->POSTED == 1) ? "checked" : "") . '  value="' . $row->NO_ID . '" ' . (($row->POSTED == 2) ? "disabled" : "") . '></input>
                    ';

            })

            ->rawColumns(['action', 'cek'])
            ->make(true);
    }

//////////////////////////////////////////////////////////////////////////////////

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Resbelinse
     */
    public function store(Request $request)
    {
        $this->validate(
            $request,
            [
                'TGL' => 'required',
            ]
        );

        $CBG     = Auth::user()->CBG;
        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
        $bulan   = session()->get('periode')['bulan'];
        $tahun   = substr(session()->get('periode')['tahun'], -2);

        ////// Nomor Bukti Otomatis
        $last = DB::table('po')
            ->select('no_bukti')
            ->where('per', $periode)
            ->where('flag', 'PZ')
            ->where('cbg', $CBG)
            ->orderByDesc('no_bukti')
            ->first();

        if ($last) {
            $lastNumber = (int) substr($last->no_bukti, -4);
            $newNumber  = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            $no_bukti   = 'PO' . $CBG . $tahun . $bulan . '-' . $newNumber;
        } else {
            $no_bukti = 'PO' . $CBG . $tahun . $bulan . '-0001';
        }

        ////// Simpan Header (PO)
        $po = Po::create([
            'no_bukti'  => $no_bukti,
            'tgl'       => date('Y-m-d', strtotime($request['TGL'])),
            'tgo'       => now(),
            'tgl_mulai' => now(),
            'jtempo'    => ($request['JTEMPO']) ? date('Y-m-d', strtotime($request['JTEMPO'])) : now()->addDays(5),
            'tkk1'      => now()->addDays(5),
            'tkks'      => now()->addDays(4),
            'type'      => 'SK',
            'per'       => $periode,
            'flag'      => 'PZ',
            'total_qty' => (float) str_replace(',', '', $request['TOTAL_QTY']),
            'total'     => (float) str_replace(',', '', $request['TOTAL']),
            'nett'      => (float) str_replace(',', '', $request['NETT']),
            'notes'     => ($request['NOTES']) ? $request['NOTES'] : '',
            'usrnm'     => Auth::user()->username,
            'tg_smp'    => now(),
            'cbg'       => $CBG,
            'utuh'      => 'U',
            'krm_eml'   => 1,
            'kodes'     => 'AAA',
            'namas'     => 'TGZ',
        ]);

        ////// Simpan Detail (POD)
        $REC     = $request->input('REC');
        $KD_BRG  = $request->input('KD_BRG');
        $NA_BRG  = $request->input('NA_BRG');
        $KET_UK  = $request->input('KET_UK');
        $KDLAKU  = $request->input('KDLAKU');
        $KEMASAN = $request->input('KEMASAN');
        $QTY     = $request->input('QTY');
        $HARGA   = $request->input('HARGA');
        $TOTAL   = $request->input('TOTAL');
        $NOTES   = $request->input('NOTES_DETAIL');

        if ($REC) {
            foreach ($REC as $key => $value) {
                $detail            = new Pod;
                $detail->no_bukti  = $no_bukti;
                $detail->rec       = $REC[$key];
                $detail->per       = $periode;
                $detail->flag      = 'PZ';
                $detail->type      = 'SK';
                $detail->tgo       = now();
                $detail->tgl_mulai = now();
                $detail->cbg       = $CBG;
                $detail->kd_brg    = ($KD_BRG[$key]) ? $KD_BRG[$key] : '';
                $detail->na_brg    = ($NA_BRG[$key]) ? $NA_BRG[$key] : '';
                $detail->ket_uk    = ($KET_UK[$key]) ? $KET_UK[$key] : '';
                $detail->kdlaku    = ($KDLAKU[$key]) ? $KDLAKU[$key] : '';
                $detail->ket_kem   = ($KEMASAN[$key]) ? $KEMASAN[$key] : '';
                $detail->qty       = (float) str_replace(',', '', $QTY[$key]);
                $detail->sisa      = (float) str_replace(',', '', $QTY[$key]);
                $detail->harga     = (float) str_replace(',', '', $HARGA[$key]);
                $detail->total     = (float) str_replace(',', '', $TOTAL[$key]);
                $detail->ket       = ($NOTES[$key]) ? $NOTES[$key] : '';
                $detail->id_po     = $po->no_id;
                $detail->save();

            }
        }

        ////// Update ID di detail (sinkronisasi)
        DB::statement("UPDATE pod, po
                   SET pod.id = po.no_id
                   WHERE po.no_bukti = pod.no_bukti
                   AND po.no_bukti = '$no_bukti'");

        return redirect('/po/edit/?idx=' . $po->no_id . '&tipx=edit&flagz=PZ&judul=PO&golz=');
    }

    public function edit(Request $request, Orderk $orderk)
    {

        $per = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];


        $this->setFlag($request);

        $tipx = $request->tipx;

        $idx = $request->idx;

        $CBG = Auth::user()->CBG;

        if ($idx == '0' && $tipx == 'undo') {
            $tipx = 'top';

        }

        if ($tipx == 'search') {

            $buktix = $request->buktix;

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		                 where PER ='$per' and FLAG ='$this->FLAGZ'
						 and NO_BUKTI = '$buktix'
                         AND CBG = '$CBG'
		                 ORDER BY NO_BUKTI ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'top') {

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		                 where PER ='$per'
						 and FLAG ='$this->FLAGZ'
                         AND CBG = '$CBG'
		                 ORDER BY NO_BUKTI ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'prev') {

            $buktix = $request->buktix;

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		             where PER ='$per'
					 and FLAG ='$this->FLAGZ'
                     AND CBG = '$CBG'
                     and NO_BUKTI <
					 '$buktix' ORDER BY NO_BUKTI DESC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }

        if ($tipx == 'next') {

            $buktix = $request->buktix;

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		             where PER ='$per'
					 and FLAG ='$this->FLAGZ'
                     AND CBG = '$CBG'
                     and NO_BUKTI >
					 '$buktix' ORDER BY NO_BUKTI ASC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }

        if ($tipx == 'bottom') {

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
						where PER ='$per'
						and FLAG ='$this->FLAGZ'
                        AND CBG = '$CBG'
		                ORDER BY NO_BUKTI DESC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'undo' || $tipx == 'search') {

            $tipx = 'edit';

        }

        if ($idx != 0) {
            $orderk = Orderk::where('NO_ID', $idx)->first();
        } else {
            $orderk      = new Orderk;
            $orderk->TGL = Carbon::now();

        }

        $no_bukti     = $orderk->NO_BUKTI;
        $orderkDetail = DB::table('orderkd')->where('NO_BUKTI', $no_bukti)->orderBy('REC')->get();

        $data = [
            'header' => $orderk,
            'detail' => $orderkDetail,

        ];

        $sup = DB::SELECT("SELECT KODES, CONCAT(NAMAS,'-',KOTA) AS NAMAS FROM SUP
		                 ORDER BY NAMAS ASC");

        return view('otransaksi_orderk.edit', $data)->with(['sup' => $sup])
            ->with(['tipx' => $tipx, 'idx' => $idx, 'flagz' => $this->FLAGZ, 'golz' => $this->GOLZ, 'judul' => $this->judul]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Resbelinse
     */

    // ganti 18

  public function update(Request $request, Po $po)
{
    $this->validate(
        $request,
        [
            'TGL' => 'required',
        ]
    );

    $CBG     = Auth::user()->CBG;
    $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

    ////// Update Header PO
    $po = Po::findOrFail($id);
    $po->update([
        'tgl'        => date('Y-m-d', strtotime($request['TGL'])),
        'jtempo'     => ($request['JTEMPO']) ? date('Y-m-d', strtotime($request['JTEMPO'])) : null,
        'notes'      => ($request['NOTES']) ? $request['NOTES'] : '',
        'total_qty'  => (float) str_replace(',', '', $request['TOTAL_QTY']),
        'total'      => (float) str_replace(',', '', $request['TOTAL']),
        'nett'       => (float) str_replace(',', '', $request['NETT']),
        'usrnm'      => Auth::user()->username,
        'tg_smp'     => now(),
    ]);

    $REC     = $request->input('REC');
    $NO_ID   = $request->input('NO_ID'); // hidden input utk tracking
    $KD_BRG  = $request->input('KD_BRG');
    $NA_BRG  = $request->input('NA_BRG');
    $KET_UK  = $request->input('KET_UK');
    $KDLAKU  = $request->input('KDLAKU');
    $KEMASAN = $request->input('KEMASAN');
    $QTY     = $request->input('QTY');
    $HARGA   = $request->input('HARGA');
    $TOTAL   = $request->input('TOTAL');
    $NOTES   = $request->input('NOTES_DETAIL');

    $existingIds = [];

    if ($REC) {
        foreach ($REC as $key => $value) {
            if (!empty($NO_ID[$key]) && $NO_ID[$key] > 0) {
                ////// UPDATE detail lama
                $detail = Pod::find($NO_ID[$key]);
                if ($detail) {
                    $detail->update([
                        'rec'      => $REC[$key],
                        'kd_brg'   => ($KD_BRG[$key]) ? $KD_BRG[$key] : '',
                        'na_brg'   => ($NA_BRG[$key]) ? $NA_BRG[$key] : '',
                        'ket_uk'   => ($KET_UK[$key]) ? $KET_UK[$key] : '',
                        'kdlaku'   => ($KDLAKU[$key]) ? $KDLAKU[$key] : '',
                        'ket_kem'  => ($KEMASAN[$key]) ? $KEMASAN[$key] : '',
                        'qty'      => (float) str_replace(',', '', $QTY[$key]),
                        'sisa'     => (float) str_replace(',', '', $QTY[$key]),
                        'harga'    => (float) str_replace(',', '', $HARGA[$key]),
                        'total'    => (float) str_replace(',', '', $TOTAL[$key]),
                        'ket'      => ($NOTES[$key]) ? $NOTES[$key] : '',
                        'usrnm'    => Auth::user()->username,
                    ]);
                    $existingIds[] = $detail->no_id;
                }
            } else {
                ////// INSERT detail baru
                $detail = Pod::create([
                    'no_bukti'   => $po->no_bukti,
                    'rec'        => $REC[$key],
                    'per'        => $periode,
                    'flag'       => 'PZ',
                    'type'       => 'SK',
                    'tgo'        => now(),
                    'tgl_mulai'  => now(),
                    'cbg'        => $CBG,
                    'kd_brg'     => ($KD_BRG[$key]) ? $KD_BRG[$key] : '',
                    'na_brg'     => ($NA_BRG[$key]) ? $NA_BRG[$key] : '',
                    'ket_uk'     => ($KET_UK[$key]) ? $KET_UK[$key] : '',
                    'kdlaku'     => ($KDLAKU[$key]) ? $KDLAKU[$key] : '',
                    'ket_kem'    => ($KEMASAN[$key]) ? $KEMASAN[$key] : '',
                    'qty'        => (float) str_replace(',', '', $QTY[$key]),
                    'sisa'       => (float) str_replace(',', '', $QTY[$key]),
                    'harga'      => (float) str_replace(',', '', $HARGA[$key]),
                    'total'      => (float) str_replace(',', '', $TOTAL[$key]),
                    'ket'        => ($NOTES[$key]) ? $NOTES[$key] : '',
                    'id_po'      => $po->no_id,
                ]);
                $existingIds[] = $detail->no_id;
            }
        }
    }

    ////// Hapus detail yang tidak ada lagi di request (DELETE)
    Pod::where('no_bukti', $po->no_bukti)
        ->whereNotIn('no_id', $existingIds)
        ->delete();

    ////// Sinkronisasi ID detail
    DB::statement("UPDATE pod, po 
                   SET pod.id = po.no_id  
                   WHERE po.no_bukti = pod.no_bukti 
                   AND po.no_bukti = ?", [$po->no_bukti]);

    return redirect('/po/edit/?idx=' . $po->no_id . '&tipx=edit&flagz=PZ&judul=PO&golz=');
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Resbelinse
     */

    // ganti 22

    public function destroy(Request $request, Po $po)
    {

        $this->setFlag($request);
        $FLAGZ = $this->FLAGZ;
        $GOLZ  = $this->GOLZ;
        $judul = $this->judul;

        $per      = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];
        $cekperid = DB::SELECT("SELECT POSTED from perid WHERE PERIO='$per'");
        if ($cekperid[0]->POSTED == 1) {
            return redirect()->route('po')
                ->with('status', 'Maaf Periode sudah ditutup!')
                ->with(['judul' => $this->judul, 'flagz' => $this->FLAGZ]);
        }

        // DB::SELECT("CALL orderkdel('$orderk->NO_BUKTI')");

        $deletePo = Po::find($po->NO_ID);

        $deletePo->delete();

        return redirect('/po?flagz=' . $FLAGZ)->with(['judul' => $judul, 'flagz' => $FLAGZ, 'golz' => $GOLZ])->with('statusHapus', 'Data ' . $orderk->NO_BUKTI . ' berhasil dihapus');

    }

}