<?php
namespace App\Http\Controllers\OTransaksi;

use App\Http\Controllers\Controller;
// ganti 1

use App\Models\Transaksi\Po;
use App\Models\Transaksi\Pod;
use Auth;
use Carbon\Carbon;
use DataTables;
use DB;
use Illuminate\Http\Request;

include_once base_path() . "/vendor/simitgroup/phpjasperxml/version/1.1/PHPJasperXML.inc.php";

// ganti 2
class PsnOutletController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Resbelinse
     */
    public $judul = '';
    public $FLAGZ = '';
    public $GOLZ  = '';

    public function setFlag(Request $request)
    {
        if ($request->flagz == 'OK' && $request->golz == 'J') {
            $this->judul = "Order Kerja";
        } else if ($request->flagz == '' && $request->golz == '') {
            $this->judul = "";
        }

        $this->FLAGZ = $request->flagz;
        $this->GOLZ  = $request->golz;

    }

    public function index(Request $request)
    {

        $this->setFlag($request);
        // ganti 3
        return view('otransaksi_psn_outlet.index')->with(['judul' => $this->judul, 'flagz' => $this->FLAGZ, 'golz' => $this->GOLZ]);

    }

    public function getPesanOutlet(Request $request)
    {
        // ganti 5

        if ($request->session()->has('periode')) {
            $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
        } else {
            $periode = '';
        }

        $this->setFlag($request);
        $cbg = $request->cbg;

        if ($cbg == 'ma') {
            $sql = DB::select("SELECT *
            FROM {$OO}.po
            WHERE per = ='$periode'
              AND FLAG = 'PZ'
              AND type = 'SK'
            ORDER BY NO_BUKTI");
        } else {
            $sql = DB::select("SELECT * FROM {$OO}.po
                    WHERE per = ='$periode'
                    AND FLAG = 'PZ'
                    AND type = 'SK'
                    AND cbg = '$cbg'
                    ORDER BY NO_BUKTI");
        }

        // ganti 6

        return Datatables::of($orderk)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                if (Auth::user()->divisi == "programmer") {
                    //CEK POSTED di index dan edit

                    $btnEdit   = ($row->POSTED == 1) ? ' onclick= "alert(\'Transaksi ' . $row->NO_BUKTI . ' sudah diorderksting!\')" href="#" ' : ' href="psn-outlet/edit/?idx=' . $row->NO_ID . '&tipx=edit&flagz=' . $row->FLAG . '&judul=' . $this->judul . '&golz=' . $row->GOL . '"';
                    $btnDelete = ($row->POSTED == 1) ? ' onclick= "alert(\'Transaksi ' . $row->NO_BUKTI . ' sudah diorderksting!\')" href="#" ' : ' onclick="return confirm(&quot; Apakah anda yakin ingin hapus? &quot;)" href="psn-outlet/delete/' . $row->NO_ID . '/?flagz=' . $row->FLAG . '&golz=' . $row->GOL . '" ';

                    $btnPrivilege =
                    '
                                <a class="dropdown-item" ' . $btnEdit . '>
                                <i class="fas fa-edit"></i>
                                    Edit
                                </a>
                                <a class="dropdown-item btn btn-danger" href="cetak/' . $row->NO_ID . '">
                                    <i class="fa fa-print" aria-hidden="true"></i>
                                    Print
                                </a>
                                <hr></hr>
                                <a class="dropdown-item btn btn-danger" ' . $btnDelete . '>

                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    Delete
                                </a>
                        ';
                } else {
                    $btnPrivilege = '';
                }

                $actionBtn =
                    '
                    <div class="dropdown show" style="text-align: center">
                        <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-hasorderkpup="true" aria-expanded="false">
                            <i class="fas fa-bars"></i>
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">


                            ' . $btnPrivilege . '
                        </div>
                    </div>
                    ';

                return $actionBtn;
            })

            ->addColumn('cek', function ($row) {
                return;
                '
                    <input type="checkbox" name="cek[]" class="form-control cek" ' . (($row->POSTED == 1) ? "checked" : "") . '  value="' . $row->NO_ID . '" ' . (($row->POSTED == 2) ? "disabled" : "") . '></input>
                    ';

            })

            ->rawColumns(['action', 'cek'])
            ->make(true);
    }

//////////////////////////////////////////////////////////////////////////////////

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Resbelinse
     */
    public function store(Request $request)
    {
        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
        
        if ($request->no_bukti == '+') {
            $last = DB::table('po')
                ->where('PER', $periode)
                ->orderByDesc('NO_BUKTI')
                ->first();

            if ($last) {
                // ambil nomor terakhir lalu increment
                $lastNumber = (int) substr($last->NO_BUKTI, -4);
                $newNumber  = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            } else {
                $newNumber = '0001';
            }

            $no_bukti = "PO-" . substr($periode, 4, 2) . substr($periode, 2, 2) . "-" . $newNumber;
        } else {
            $no_bukti = $request->no_bukti;
        }

        $idHeader = DB::table('po')->insertGetId([
            'NO_BUKTI'  => $no_bukti,
            'TGL'       => $request->tgl,
            'PER'       => $request->periode,
            'NOTES'     => $request->notes,
            'TOTAL_QTY' => $request->total_qty,
            'TOTAL'     => $request->total,
            'NETT'      => $request->nett,
            'USRNM'     => $request->usrnm,
        ]);

        // === Simpan Detail ===
        if ($request->has('details')) {
            foreach ($request->details as $i => $detail) {
                DB::table('pod')->insert([
                    'NO_BUKTI' => $no_bukti,
                    'REC'      => $i + 1,
                    'KD_BRG'   => $detail['KD_BRG'],
                    'NA_BRG'   => $detail['NA_BRG'],
                    'kemasan'  => $detail['kemasan'],
                    'QTY'      => $detail['QTY'],
                    'HARGA'    => $detail['HARGA'],
                    'TOTAL'    => $detail['TOTAL'],
                    'NOTES'    => $detail['NOTES'],
                ]);
            }
        }

        return redirect('/psn-outlet/edit/?idx=' . $idHeader . '&tipx=edit&flagz=' . $this->FLAGZ . '&judul=' . $this->judul . '&golz=' . $this->GOLZ);
    }

    public function edit(Request $request, Orderk $orderk)
    {

        $per = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];

        // $cekperid = DB::SELECT("SELECT POSTED from perid WHERE PERIO='$per'");
        // if ($cekperid[0]->POSTED==1)
        // {
        //     return redirect('/orderk')
        // 	       ->with('status', 'Maaf Periode sudah ditutup!')
        //            ->with(['judul' => $judul, 'flagz' => $FLAGZ]);
        // }

        $this->setFlag($request);

        $tipx = $request->tipx;

        $idx = $request->idx;

        $CBG = Auth::user()->CBG;

        if ($idx == '0' && $tipx == 'undo') {
            $tipx = 'top';

        }

        if ($tipx == 'search') {

            $buktix = $request->buktix;

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		                 where PER ='$per' and FLAG ='$this->FLAGZ'
						 and NO_BUKTI = '$buktix'
                         AND CBG = '$CBG'
		                 ORDER BY NO_BUKTI ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'top') {

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		                 where PER ='$per'
						 and FLAG ='$this->FLAGZ'
                         AND CBG = '$CBG'
		                 ORDER BY NO_BUKTI ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'prev') {

            $buktix = $request->buktix;

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		             where PER ='$per'
					 and FLAG ='$this->FLAGZ'
                     AND CBG = '$CBG'
                     and NO_BUKTI <
					 '$buktix' ORDER BY NO_BUKTI DESC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }

        if ($tipx == 'next') {

            $buktix = $request->buktix;

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
		             where PER ='$per'
					 and FLAG ='$this->FLAGZ'
                     AND CBG = '$CBG'
                     and NO_BUKTI >
					 '$buktix' ORDER BY NO_BUKTI ASC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }

        if ($tipx == 'bottom') {

            $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from orderk
						where PER ='$per'
						and FLAG ='$this->FLAGZ'
                        AND CBG = '$CBG'
		                ORDER BY NO_BUKTI DESC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'undo' || $tipx == 'search') {

            $tipx = 'edit';

        }

        if ($idx != 0) {
            $orderk = Orderk::where('NO_ID', $idx)->first();
        } else {
            $orderk      = new Orderk;
            $orderk->TGL = Carbon::now();

        }

        $no_bukti     = $orderk->NO_BUKTI;
        $orderkDetail = DB::table('orderkd')->where('NO_BUKTI', $no_bukti)->orderBy('REC')->get();

        $data = [
            'header' => $orderk,
            'detail' => $orderkDetail,

        ];

        $sup = DB::SELECT("SELECT KODES, CONCAT(NAMAS,'-',KOTA) AS NAMAS FROM SUP
		                 ORDER BY NAMAS ASC");

        return view('otransaksi_orderk.edit', $data)->with(['sup' => $sup])
            ->with(['tipx' => $tipx, 'idx' => $idx, 'flagz' => $this->FLAGZ, 'golz' => $this->GOLZ, 'judul' => $this->judul]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Resbelinse
     */

    // ganti 18

    public function update(Request $request, Orderk $orderk)
    {

        $this->validate(
            $request,
            [

                // 'NO_BUKTI'   => 'required',
                'TGL' => 'required',
            ]
        );

        $this->setFlag($request);
        $GOLZ  = $this->GOLZ;
        $FLAGZ = $this->FLAGZ;
        $judul = $this->judul;

        $CBG = Auth::user()->CBG;

        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $orderk->update(
            [
                'TGL'          => date('Y-m-d', strtotime($request['TGL'])),
                'JTEMPO'       => date('Y-m-d', strtotime($request['JTEMPO'])),
                'NO_SO'        => ($request['NO_SO'] == null) ? "" : $request['NO_SO'],
                'KODEC'        => ($request['KODEC'] == null) ? "" : $request['KODEC'],
                'NAMAC'        => ($request['NAMAC'] == null) ? "" : $request['NAMAC'],
                'ALAMAT'       => ($request['ALAMAT'] == null) ? "" : $request['ALAMAT'],
                'KOTA'         => ($request['KOTA'] == null) ? "" : $request['KOTA'],
                'NOTES'        => ($request['NOTES'] == null) ? "" : $request['NOTES'],
                'TOTAL_QTY'    => (float) str_replace(',', '', $request['TOTAL_QTY']),
                'TOTAL_QTY_SO' => (float) str_replace(',', '', $request['TOTAL_QTY_SO']),
                'USRNM'        => Auth::user()->username,
                'GOL'          => $GOLZ,
                'FLAG'         => $FLAGZ,
                'CBG'          => $CBG,
                'TG_SMP'       => Carbon::now(),

            ]
        );

        $no_buktix = $orderk->NO_BUKTI;

        // Update Detail
        $length = sizeof($request->input('REC'));
        $NO_ID  = $request->input('NO_ID');
        $REC    = $request->input('REC');
        $KD_BRG = $request->input('KD_BRG');
        $NA_BRG = $request->input('NA_BRG');
        $SATUAN = $request->input('SATUAN');
        $NO_FO  = $request->input('NO_FO');
        $QTY    = $request->input('QTY');
        $QTY_SO = $request->input('QTY_SO');

        // Delete yang NO_ID tidak ada di input
        $query = DB::table('orderkd')->where('NO_BUKTI', $orderk->NO_BUKTI)->whereNotIn('NO_ID', $NO_ID)->delete();

        // Update / Insert
        for ($i = 0; $i < $length; $i++) {
            // Insert jika NO_ID baru
            if ($NO_ID[$i] == 'new') {
                $insert = OrderkDetail::create(
                    [
                        'NO_BUKTI' => $orderk->NO_BUKTI,
                        // 'NO_SO'      => ($NO_SO[$i]==null) ? "" :  $NO_SO[$i],
                        'REC'      => $REC[$i],
                        'PER'      => $orderk->PER,
                        'FLAG'     => 'SJ',
                        'GOL'      => $GOLZ,
                        'KD_BRG'   => ($KD_BRG[$i] == null) ? "" : $KD_BRG[$i],
                        'NA_BRG'   => ($NA_BRG[$i] == null) ? "" : $NA_BRG[$i],
                        'SATUAN'   => ($SATUAN[$i] == null) ? "" : $SATUAN[$i],
                        'NO_FO'    => ($NO_FO[$i] == null) ? "" : $NO_FO[$i],
                        'QTY'      => (float) str_replace(',', '', $QTY[$i]),
                        'QTY_SO'   => (float) str_replace(',', '', $QTY_SO[$i]),
                        'ID'       => $orderk->NO_ID,
                    ]
                );
            } else {
                // Update jika NO_ID sudah ada
                $update = OrderkDetail::updateOrCreate(
                    [
                        'NO_BUKTI' => $orderk->NO_BUKTI,
                        'NO_ID'    => (int) str_replace(',', '', $NO_ID[$i]),
                    ],

                    [
                        // 'NO_SO'      => ($NO_SO[$i]==null) ? "" :  $NO_SO[$i],
                        'REC'    => $REC[$i],
                        'FLAG'   => 'SJ',
                        'GOL'    => $GOLZ,
                        'KD_BRG' => ($KD_BRG[$i] == null) ? "" : $KD_BRG[$i],
                        'NA_BRG' => ($NA_BRG[$i] == null) ? "" : $NA_BRG[$i],
                        'SATUAN' => ($SATUAN[$i] == null) ? "" : $SATUAN[$i],
                        'NO_FO'  => ($NO_FO[$i] == null) ? "" : $NO_FO[$i],
                        'QTY'    => (float) str_replace(',', '', $QTY[$i]),
                        'QTY_SO' => (float) str_replace(',', '', $QTY_SO[$i]),
                    ]
                );
            }
        }

        // DB::SELECT("CALL orderkins('$orderk->NO_BUKTI')");

        $orderk = Orderk::where('NO_BUKTI', $no_buktix)->first();

        $no_bukti = $orderk->NO_BUKTI;

        DB::SELECT("UPDATE orderk,  orderkd
                    SET  orderkd.ID =  orderk.NO_ID  WHERE  orderk.NO_BUKTI =  orderkd.NO_BUKTI
                    AND  orderk.NO_BUKTI='$no_bukti';");

        return redirect('/psn-outlet/edit/?idx=' . $orderk->NO_ID . '&tipx=edit&flagz=' . $this->FLAGZ . '&judul=' . $this->judul . '&golz=' . $this->GOLZ . '');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Resbelinse
     */

    // ganti 22

    public function destroy(Request $request, Orderk $orderk)
    {

        $this->setFlag($request);
        $FLAGZ = $this->FLAGZ;
        $GOLZ  = $this->GOLZ;
        $judul = $this->judul;

        $per      = session()->get('periode')['bulan'] . '/' . session()->get('periode')['tahun'];
        $cekperid = DB::SELECT("SELECT POSTED from perid WHERE PERIO='$per'");
        if ($cekperid[0]->POSTED == 1) {
            return redirect()->route('orderk')
                ->with('status', 'Maaf Periode sudah ditutup!')
                ->with(['judul' => $this->judul, 'flagz' => $this->FLAGZ]);
        }

        // DB::SELECT("CALL orderkdel('$orderk->NO_BUKTI')");

        $deleteOrderk = Orderk::find($orderk->NO_ID);

        $deleteOrderk->delete();

        return redirect('/psn-outlet?flagz=' . $FLAGZ)->with(['judul' => $judul, 'flagz' => $FLAGZ, 'golz' => $GOLZ])->with('statusHapus', 'Data ' . $orderk->NO_BUKTI . ' berhasil dihapus');

    }
}