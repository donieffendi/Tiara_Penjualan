<?php
namespace App\Http\Controllers\Master;

use App\Http\Controllers\Controller;
use App\Models\Master\Sup;
use Auth;
use DataTables;
use DB;
use Illuminate\Http\Request;

class SuplierController extends Controller
{

    public function index()
    {
        return view('master_daftar_supplier.index');
    }

    public function getSup(Request $request)
    {
        $query = DB::select("SELECT * from sup  order by kodes");

        return Datatables::of($query)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                if (Auth::user()->divisi == "programmer") {

                    $btnPrivilege =
                    '
                                    <a class="dropdown-item" href="sup/edit/?idx=' . $row->NO_ID . '&tipx=edit";
                                    <i class="fas fa-edit"></i>
                                        Edit
                                    </a>
                                    <hr></hr>
                                    <a class="dropdown-item btn btn-danger" onclick="return confirm(&quot; Apakah anda yakin ingin hapus? &quot;)" href="sup/delete/' . $row->NO_ID . '">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    Delete
                                    </a>
                            ';
                } else {
                    $btnPrivilege = '';
                }

                $actionBtn =
                '
                        <div class="dropdown show" style="text-align: center">
                            <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bars"></i>
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a hidden class="dropdown-item" href="sup/show/' . $row->NO_ID . '">
                                <i class="fas fa-eye"></i>
                                    Lihat
                                </a>

                                ' . $btnPrivilege . '
                            </div>
                        </div>
                        ';

                return $actionBtn;
            })
            ->rawColumns(['action'])
            ->make(true);
    }

    public function store(Request $request)
    {
        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $bulan = str_pad(session()->get('periode')['bulan'], 2, '0', STR_PAD_LEFT);
        $tahun = session()->get('periode')['tahun'];

        $query = DB::table('supp')
            ->select('KODES')
            ->where('KODES', 'like', 'HR' . $tahun . $bulan . '%')
            ->orderByDesc('KODES')
            ->first();

        if ($query) {
            $lastNumber = intval(substr($query->KODES, -3));
            $newNumber  = str_pad($lastNumber + 1, 3, '0', STR_PAD_LEFT);
        } else {
            $newNumber = '001';
        }

        $no_bukti = 'SUP' . $tahun . $bulan . $newNumber;

        // Insert Header

        // ganti 10

        $sup = Sup::create(
            [
                'KODES'   => $no_bukti,
                'NAMAS'   => ($request['NAMAS'] == null) ? "" : $request['NAMAS'],
                'STAND'   => ($request['STAND'] == null) ? "" : $request['STAND'],
                'AN_BP'   => ($request['AN_BP'] == null) ? "" : $request['AN_BP'],
                'NO_REK'  => ($request['NO_REK'] == null) ? "" : $request['NO_REK'],
                'NAMA_BP' => ($request['NAMA_BP'] == null) ? "" : $request['NAMA_BP'],
                'KOTA_BP' => ($request['KOTA_BP'] == null) ? "" : $request['KOTA_BP'],
                'MARGIN'  => (float) str_replace(',', '', $request['MARGIN']),
            ]
        );

        //  ganti 11

        return redirect('/sup')->with('statusInsert', 'Data baru berhasil ditambahkan');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 15

    public function edit(Request $request, Sup $sup)
    {

        // ganti 16
        $tipx = $request->tipx;

        $idx = $request->idx;

        $cbg = Auth::user()->CBG;

        if ($idx == '0' && $tipx == 'undo') {
            $tipx = 'top';

        }

        if ($tipx == 'search') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, KODES from supp
		                 where KODES = '$kodex'
		                 ORDER BY KODES ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'top') {

            $bingco = DB::SELECT("SELECT NO_ID, KODES from supp
		                 ORDER BY KODES ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'prev') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, KODES from supp
		             where KODES <
					 '$kodex' ORDER BY KODES DESC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }
        if ($tipx == 'next') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, KODES from supp
		             where KODES >
					 '$kodex' ORDER BY KODES ASC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }

        if ($tipx == 'bottom') {

            $bingco = DB::SELECT("SELECT NO_ID, KODES from supp
		              ORDER BY KODES DESC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'undo' || $tipx == 'search') {

            $tipx = 'edit';

        }

        if ($idx != 0) {
            $sup = Sup::where('NO_ID', $idx)->first();
        } else {
            $sup = new Sup;
        }

        $data = [
            'header' => $sup,
        ];

        return view('master_daftar_supplier.edit', $data)->with(['tipx' => $tipx, 'idx' => $idx]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, Sup $sup)
    {

        // ganti 20

        $tipx = 'edit';
        $idx  = $request->idx;

        $sup->update(
            [
                'NAMAS'   => ($request['NAMAS'] == null) ? "" : $request['NAMAS'],
                'STAND'   => ($request['STAND'] == null) ? "" : $request['STAND'],
                'AN_BP'   => ($request['AN_BP'] == null) ? "" : $request['AN_BP'],
                'NO_REK'  => ($request['NO_REK'] == null) ? "" : $request['NO_REK'],
                'NAMA_BP' => ($request['NAMA_BP'] == null) ? "" : $request['NAMA_BP'],
                'KOTA_BP' => ($request['KOTA_BP'] == null) ? "" : $request['KOTA_BP'],
                'MARGIN'  => (float) str_replace(',', '', $request['MARGIN']),
            ]
        );

        return redirect('/sup')->with('status', 'Data berhasil diupdate');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 22

    public function destroy(Request $request, Sup $sup)
    {

        // ganti 23
        $deleteSup = Sup::find($sup->NO_ID);

        // ganti 24

        $deleteSup->delete();

        // ganti
        return redirect('/sup')->with('status', 'Data berhasil dihapus');
    }

}