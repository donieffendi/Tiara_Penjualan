<?php
namespace App\Http\Controllers\Master;

use App\Http\Controllers\Controller;
use App\Models\Master\BrgFC;
use Auth;
use DataTables;
use DB;
use Illuminate\Http\Request;

class DataBrg2Controller extends Controller
{

    public function index()
    {
        return view('master_data_barang_2.index');
    }

    public function getDataBrg2(Request $request)
    {

        // $query = DB::select("SELECT * FROM brgFC");
        $subDr = $request->input('subDr');
        $subSmp = $request->input('subSmp');
        $kdBrg = $request->input('kdBrg');
        $Bcd = $request->input('Bcd');

        // $sql = "SELECT NO_ID, KD_BRG, NA_BRG, KET_UK, KET_KEM, PPN, TARIK, MASA_EXP, SUPP, NAMAS, SUB FROM brg";
        $sql = "SELECT 
                a.NO_ID,
                a.SUB, 
                a.KD_BRG, 
                a.NA_BRG, 
                a.KET_UK, 
                a.KET_KEM, 
                a.PPN, 
                a.TARIK, 
                a.MASA_EXP,
                b.KODES AS SUPP, 
                b.NAMAS AS NAMAS
            FROM 
                brg AS a
            LEFT JOIN 
                sup AS b ON a.SUPP = b.KODES
            WHERE 1=1";
        $bindings = [];

        if (!empty($subDr) && !empty($subSmp)) {
            $sql .= " AND a.SUB BETWEEN ? AND ?";
            $bindings[] = $subDr;
            $bindings[] = $subSmp;
        }

        if (!empty($kdBrg)) {
            $sql .= " AND a.KD_BRG = ?";
            $bindings[] = $kdBrg;
        }

        if (!empty($Bcd)) {
            $sql .= " AND a.BARCODE = ?";
            $bindings[] = $Bcd;
        }

        $sql .= " ORDER BY KD_BRG";

        $brg = DB::select($sql, $bindings);

        return Datatables::of($brg)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                if (Auth::user()->divisi == "programmer") {
                    $btnPrivilege =
                    '
                                    <a class="dropdown-item" href="dbrg2/edit/?idx=' . $row->NO_ID . '&tipx=edit";
                                    <i class="fas fa-edit"></i>
                                        Edit
                                    </a>
                                    <hr></hr>
                                    <a class="dropdown-item btn btn-danger" onclick="return confirm(&quot; Apakah anda yakin ingin hapus? &quot;)" href="dbrg2/delete/' . $row->NO_ID . '">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    Delete
                                    </a>
                            ';
                } else {
                    $btnPrivilege = '';
                }

                $actionBtn =
                '
                        <div class="dropdown show" style="text-align: center">
                            <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bars"></i>
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a hidden class="dropdown-item" href="dbrg2/show/' . $row->NO_ID . '">
                                <i class="fas fa-eye"></i>
                                    Lihat
                                </a>

                                ' . $btnPrivilege . '
                            </div>
                        </div>
                        ';

                return $actionBtn;
            })
            ->rawColumns(['action'])
            ->make(true);
    }

    public function store(Request $request)
    {

        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $bulan = str_pad(session()->get('periode')['bulan'], 2, '0', STR_PAD_LEFT);
        $tahun = session()->get('periode')['tahun'];

        $query = DB::table('brgFC')
            ->select('SUB')
            ->where('SUB', 'like', 'HR' . $tahun . $bulan . '%')
            ->orderByDesc('SUB')
            ->first();

        if ($query) {
            $lastNumber = intval(substr($query->SUB, -3));
            $newNumber  = str_pad($lastNumber + 1, 3, '0', STR_PAD_LEFT);
        } else {
            $newNumber = '001';
        }

        $no_bukti = 'BRGFC' . $tahun . $bulan . $newNumber;

        // Insert Header

        // ganti 10

        $brgFC = BrgFC::create(
            [
                'SUB'      => $no_bukti,
                'KD_BRG'   => ($request['KD_BRG'] == null) ? "" : $request['KD_BRG'],
                'NA_BRG'   => ($request['NA_BRG'] == null) ? "" : $request['NA_BRG'],
                'KELOMPOK' => ($request['KELOMPOK'] == null) ? "" : $request['KELOMPOK'],
                'TKP'      => ($request['TKP'] == null) ? "" : $request['TKP'],
                'FLAGSTOK' => ($request['FLAGSTOK'] == null) ? "" : $request['FLAGSTOK'],
                'HJ'       => (float) str_replace(',', '', $request['HJ']),
                'HB'       => (float) str_replace(',', '', $request['HB']),
                'MARGIN'   => (float) str_replace(',', '', $request['MARGIN']),
                'MARGIN2'  => (float) str_replace(',', '', $request['MARGIN2']),
                'DIS'      => (float) str_replace(',', '', $request['DIS']),
                'HJ2'      => (float) str_replace(',', '', $request['HJ2']),
                'SUPP'     => ($request['KODES'] == null) ? "" : $request['KODES'],
                'NAMAS'    => ($request['SUPP'] == null) ? "" : $request['SUPP'],
                'BARCODE'  => ($request['BARCODE'] == null) ? "" : $request['BARCODE'],
                'STAND'    => ($request['STAND'] == null) ? "" : $request['STAND'],
                'LOK_TG'   => ($request['LOK_TG'] == null) ? "" : $request['LOK_TG'],
                'TYPE'     => ($request['TYPE'] == null) ? "" : $request['TYPE']]
        );

        //  ganti 11

        return redirect('/dbrg2')->with('statusInsert', 'Data baru berhasil ditambahkan');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 15

    public function edit(Request $request, BrgFC $dbrg)
    {

        // ganti 16
        $tipx = $request->tipx;

        $idx = $request->idx;

        $cbg = Auth::user()->CBG;

        if ($idx == '0' && $tipx == 'undo') {
            $tipx = 'top';

        }

        if ($tipx == 'search') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, SUB from brgFC
		                 where SUB = '$kodex'
		                 ORDER BY SUB ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'top') {

            $bingco = DB::SELECT("SELECT NO_ID, SUB from brgFC
		                 ORDER BY  ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'prev') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, SUB from brgFC
		             where  <
					 '$kodex' ORDER BY  DESC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }
        if ($tipx == 'next') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID,SUB  from brgFC
		             where  >
					 '$kodex' ORDER BY  ASC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }

        if ($tipx == 'bottom') {

            $bingco = DB::SELECT("SELECT NO_ID,SUB  from brgFC
		              ORDER BY  DESC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'undo' || $tipx == 'search') {

            $tipx = 'edit';

        }

        if ($idx != 0) {
            $brgFC = BrgFC::where('NO_ID', $idx)->first();
        } else {
            $brgFC = new BrgFC;
        }

        $data = [
            'header' => $brgFC,
        ];

        return view('master_data_barang_2.edit', $data)->with(['tipx' => $tipx, 'idx' => $idx]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, BrgFC $dbrg)
    {

        // ganti 20

        $tipx = 'edit';
        $idx  = $request->idx;

        $dbrg->update(
            [
                'KD_BRG'   => ($request['KD_BRG'] == null) ? "" : $request['KD_BRG'],
                'NA_BRG'   => ($request['NA_BRG'] == null) ? "" : $request['NA_BRG'],
                'KELOMPOK' => ($request['KELOMPOK'] == null) ? "" : $request['KELOMPOK'],
                'TKP'      => ($request['TKP'] == null) ? "" : $request['TKP'],
                'FLAGSTOK' => ($request['FLAGSTOK'] == null) ? "" : $request['FLAGSTOK'],
                'HJ'       => (float) str_replace(',', '', $request['HJ']),
                'HB'       => (float) str_replace(',', '', $request['HB']),
                'MARGIN'   => (float) str_replace(',', '', $request['MARGIN']),
                'MARGIN2'  => (float) str_replace(',', '', $request['MARGIN2']),
                'DIS'      => (float) str_replace(',', '', $request['DIS']),
                'HJ2'      => (float) str_replace(',', '', $request['HJ2']),
                'SUPP'     => ($request['SUPP'] == null) ? "" : $request['SUPP'],
                'NAMAS'    => ($request['NAMAS'] == null) ? "" : $request['NAMAS'],
                'BARCODE'  => ($request['BARCODE'] == null) ? "" : $request['BARCODE'],
                'STAND'    => ($request['STAND'] == null) ? "" : $request['STAND'],
                'LOK_TG'   => ($request['LOK_TG'] == null) ? "" : $request['LOK_TG'],
                'TYPE'     => ($request['TYPE'] == null) ? "" : $request['TYPE'],
            ]
        );

        return redirect('/dbrg2')->with('status', 'Data berhasil diupdate');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 22

    public function destroy(Request $request, BrgFC $dbrg)
    {

        // ganti 23
        $deleteBrgFC = BrgFC::find($dbrg->NO_ID);

        // ganti 24

        $deleteBrgFC->delete();

        // ganti
        return redirect('/dbrg2')->with('status', 'Data berhasil dihapus');
    }

}