<?php
namespace App\Http\Controllers\Master;

use App\Http\Controllers\Controller;
use App\Models\Master\Komisi;
use App\Models\Master\KomisiDetail;
use Auth;
use Carbon\Carbon;
use DataTables;
use DB;
use Illuminate\Http\Request;

class KomisiController extends Controller
{

    public function index()
    {
        return view('master_daftar_komisi.index');
    }

    public function getKomisi(Request $request)
    {
        $query = DB::select("SELECT * FROM komisi");

        return Datatables::of($query)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                if (Auth::user()->divisi == "programmer") {

                    $btnPrivilege =
                    '
                                    <a class="dropdown-item" href="komisi/edit/?idx=' . $row->NO_ID . '&tipx=edit";
                                    <i class="fas fa-edit"></i>
                                        Edit
                                    </a>
                                    <hr></hr>
                                    <a class="dropdown-item btn btn-danger" onclick="return confirm(&quot; Apakah anda yakin ingin hapus? &quot;)" href="komisi/delete/' . $row->NO_ID . '">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    Delete
                                    </a>
                            ';
                } else {
                    $btnPrivilege = '';
                }

                $actionBtn =
                '
                        <div class="dropdown show" style="text-align: center">
                            <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bars"></i>
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a hidden class="dropdown-item" href="komisi/show/' . $row->NO_ID . '">
                                <i class="fas fa-eye"></i>
                                    Lihat
                                </a>

                                ' . $btnPrivilege . '
                            </div>
                        </div>
                        ';

                return $actionBtn;
            })
            ->rawColumns(['action'])
            ->make(true);
    }

    public function store(Request $request)
    {
        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $bulan = str_pad(session()->get('periode')['bulan'], 2, '0', STR_PAD_LEFT);
        $tahun = session()->get('periode')['tahun'];

        $query = DB::table('komisi')
            ->select('BUKTI')
            ->where('BUKTI', 'like', 'KMS' . $tahun . $bulan . '%')
            ->orderByDesc('BUKTI')
            ->first();

        if ($query) {
            $lastNumber = intval(substr($query->BUKTI, -3));
            $newNumber  = str_pad($lastNumber + 1, 3, '0', STR_PAD_LEFT);
        } else {
            $newNumber = '001';
        }

        $no_bukti = 'KMS' . $tahun . $bulan . $newNumber;

        // Insert Header

        // ganti 10

        $komisi = Komisi::create(
            [
                'BUKTI'  => $no_bukti,
                'TGL'    => ($request['TGL'] == null) ? "" : $request['TGL'],
                'NAMA'   => ($request['NAMA'] == null) ? "" : $request['NAMA'],
                'KODE'   => ($request['KODE'] == null) ? "" : $request['KODE'],
                'TGLM'   => ($request['TGLM'] == null) ? "" : $request['TGLM'],
                'TGLS'   => ($request['TGLS'] == null) ? "" : $request['TGLS'],
                'NOTES'  => ($request['NOTES'] == null) ? "" : $request['NOTES'],
                'USRNM'  => Auth::user()->username,
                'TG_SMP' => Carbon::now(),
            ]
        );

        $REC      = $request->input('REC');
        $MARGIN   = $request->input('MARGIN');
        $KOMISI   = $request->input('KOMISI');
        $SUB      = $request->input('SUB');
        $KELOMPOK = $request->input('KELOMPOK');

        // Check jika value detail ada/tidak
        if ($REC) {
            foreach ($REC as $key => $value) {
                // Declare new data di Model
                $detail = new KomisiDetail;

                // Insert ke Database
                $detail->NO_BUKTI = $no_bukti;
                $detail->REC      = $REC[$key];
                $detail->SUB      = ($SUB[$key] == null) ? "" : $SUB[$key];
                $detail->KELOMPOK = ($KELOMPOK[$key] == null) ? "" : $KELOMPOK[$key];
                $detail->MARGIN   = (float) str_replace(',', '', $MARGIN[$key]);
                $detail->KOMISI   = (float) str_replace(',', '', $KOMISI[$key]);
                $detail->save();
            }
        }

        //  ganti 11
        //$variablell = DB::select('call absenins(?)', array($no_bukti));

        $no_buktix = $no_bukti;

        $komisi = Komisi::where('BUKTI', $no_buktix)->first();

        DB::SELECT("UPDATE KOMISI, KOMISID
                            SET KOMISID.ID = KOMISI.NO_ID  WHERE KOMISI.BUKTI = KOMISID.NO_BUKTI
							AND KOMISI.BUKTI='$no_buktix';");

        //  ganti 11
        return redirect('/komisi')->with('statusInsert', 'Data baru berhasil ditambahkan');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 15

    public function edit(Request $request, Komisi $komisi)
    {

        // ganti 16
        $tipx = $request->tipx;

        $idx = $request->idx;

        $cbg = Auth::user()->CBG;

        if ($idx == '0' && $tipx == 'undo') {
            $tipx = 'top';

        }

        if ($tipx == 'search') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, BUKTI from komisi
		                 where BUKTI = '$kodex'
		                 ORDER BY BUKTI ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'top') {

            $bingco = DB::SELECT("SELECT NO_ID, BUKTI from komisi
		                 ORDER BY BUKTI ASC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'prev') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, BUKTI from komisi
		             where BUKTI <
					 '$kodex' ORDER BY BUKTI DESC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }
        if ($tipx == 'next') {

            $kodex = $request->kodex;

            $bingco = DB::SELECT("SELECT NO_ID, BUKTI from komisi
		             where BUKTI >
					 '$kodex' ORDER BY BUKTI ASC LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = $idx;
            }

        }

        if ($tipx == 'bottom') {

            $bingco = DB::SELECT("SELECT NO_ID, BUKTI from komisi
		              ORDER BY BUKTI DESC  LIMIT 1");

            if (! empty($bingco)) {
                $idx = $bingco[0]->NO_ID;
            } else {
                $idx = 0;
            }

        }

        if ($tipx == 'undo' || $tipx == 'search') {

            $tipx = 'edit';

        }

        if ($idx != 0) {
            $komisi = Komisi::where('NO_ID', $idx)->first();
        } else {
            $komisi = new Komisi();
        }

        $no_bukti     = $komisi->BUKTI;
        $komisiDetail = DB::table('komisid')
            ->where('NO_BUKTI', $no_bukti)
            ->get();

        $data = [
            'header' => $komisi,
            'detail' => $komisiDetail,
        ];

        return view('master_daftar_komisi.edit', $data)->with(['tipx' => $tipx, 'idx' => $idx]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, Komisi $komisi)
    {

        // ganti 20

        $tipx = 'edit';
        $idx  = $request->idx;

        $komisi->update(
            [
                'TGL'    => ($request['TGL'] == null) ? "" : $request['TGL'],
                'NAMA'   => ($request['NAMA'] == null) ? "" : $request['NAMA'],
                'KODE'   => ($request['KODE'] == null) ? "" : $request['KODE'],
                'TGLM'   => ($request['TGLM'] == null) ? "" : $request['TGLM'],
                'TGLS'   => ($request['TGLS'] == null) ? "" : $request['TGLS'],
                'NOTES'  => ($request['NOTES'] == null) ? "" : $request['NOTES'],
                'USRNM'  => Auth::user()->username,
                'TG_SMP' => Carbon::now(),
            ]
        );

        $no_bukti = $komisi->BUKTI;
        $REC      = $request->input('REC');
        $MARGIN   = $request->input('MARGIN');
        $KOMISI   = $request->input('KOMISI');
        $SUB      = $request->input('SUB');
        $KELOMPOK = $request->input('KELOMPOK');

        KomisiDetail::where('NO_BUKTI', $no_bukti)->delete();
        if ($REC && is_array($REC)) {
            foreach ($REC as $key => $value) {
                KomisiDetail::create([
                    'NO_BUKTI' => $no_bukti,
                    'REC'      => $value,
                    'SUB'      => $SUB[$key] ?? '',
                    'KELOMPOK' => $KELOMPOK[$key] ?? '',
                    'KOMISI'   => (float) str_replace(',', '', $KOMISI[$key]),
                    'MARGIN'   => (float) str_replace(',', '', $MARGIN[$key]),
                    'ID'       => $komisi->NO_ID, 
                ]);
            }
        }

        return redirect('/komisi')->with('status', 'Data berhasil diupdate');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 22

    public function destroy(Request $request, Komisi $komisi)
    {

        // ganti 23
        $deleteKomisi = Komisi::find($komisi->NO_ID);

        // ganti 24

        $deleteKomisi->delete();

        // ganti
        return redirect('/komisi')->with('status', 'Data berhasil dihapus');
    }

}