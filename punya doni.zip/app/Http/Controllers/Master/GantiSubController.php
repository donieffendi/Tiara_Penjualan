<?php

namespace App\Http\Controllers\Master;

use App\Http\Controllers\Controller;

use App\Models\Master\Ganti;
use App\Models\Master\Gantid;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Master\Brg;
use App\Models\Master\Sup;
use DataTables;
use Auth;
use DB;

class GantiSubController extends Controller
{

    public function index() {
        return view('master_ganti_sub_item.index');
    }

    public function getSub(Request $request)
    {
    
        $cbg = Auth::user()->CBG;
        $per = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];

        $sub = DB::SELECT("SELECT * FROM ganti where per='$per' and FLAG='KD' and CBG='$cbg' order by NO_BUKTI");

        return Datatables::of($sub)
                ->addIndexColumn()
                ->addColumn('action', function($row) {
					if (Auth::user()->divisi=="programmer" || Auth::user()->divisi=="owner" || Auth::user()->divisi=="sales")
					{   
                        // url untuk delete di index
                        $url = "'".url("gsub/delete/" . $row->NO_ID )."'";
                        // batas
                        
                        $btnDelete = ' onclick="deleteRow('.$url.')"';
    
                        $btnPrivilege =
                            '
                                    <a class="dropdown-item" href="gsub/edit/?idx=' . $row->NO_ID . '&tipx=edit";
                                    <i class="fas fa-edit"></i>
                                        Edit
                                    </a>
                                    <hr></hr>
                                    <a hidden class="dropdown-item btn btn-danger" ' . $btnDelete . '>
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                        Delete
                                    </a>
                            ';
                    } else {
                        $btnPrivilege = '';
                    }
    
                    $actionBtn =
                        '
                        <div class="dropdown show" style="text-align: center">
                            <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bars"></i>
                            </a>
    
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a hidden class="dropdown-item" href="gsub/show/' . $row->NO_ID . '">
                                <i class="fas fa-eye"></i>
                                    Lihat
                                </a>
    
                                ' . $btnPrivilege . '
                            </div>
                        </div>
                        ';
    
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
    }

    public function store(Request $request)
    {


        $this->validate(
            $request,
            [
                'TGL'       => 'required'

            ]

        );

        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
        $cbg     = Auth::user()->CBG;
        $usrnm   = Auth::user()->name;

        // Generate no_bukti 
        $noBukti = $request->no_bukti;
        $bulan   = substr($periode, 0, 2);
        $tahun   = substr($periode, 3, 4);

        // Ambil counter dari notrans
        $row = DB::table('notrans')
                ->where('trans', 'GNTSUB')
                ->where('per', $tahun)
                ->first();

        $counter = $row ? $row->{'NOM'.$bulan} : 0;
        $counter++;

        // Update counter
        DB::table('notrans')
                ->where('trans', 'GNTSUB')
                ->where('per', $tahun)
                ->update(['NOM'.$bulan => $counter]);

        $kode2   = DB::table('toko')->where('kode', $cbg)->value('type');
        $noUrut  = str_pad($counter, 4, '0', STR_PAD_LEFT);
        $no_bukti = 'KD' . $tahun . $bulan . '-' . $noUrut . $kode2;
 
        // Insert Header

        $gsub = Ganti::create(
            [
                'NO_BUKTI'=> $no_bukti, 
                'TGL'     => date('Y-m-d', strtotime($request['TGL'])),
                'NOTES'   => $request['NOTES'] ?? '',
                'PER'     => $periode,
                'FLAG'    => 'KD',
                'USRNM'   => Auth::user()->username,
                'TG_SMP'  => Carbon::now(),
                'CBG'       => $cbg
            ]
        );

	    $parentID = $gsub->NO_ID;

        // Insert detail data
        $length = sizeof($request->input('REC'));

        $REC    = $request->input('REC');
        $KD_BRG   = $request->input('KD_BRG');
        $NA_BRG  = $request->input('NA_BRG');
        $KET_UK   = $request->input('KET_UK');
        $KET_KEM  = $request->input('KET_KEM');
        $KD_BRG2  = $request->input('KD_BRG2');

        for ($i = 0; $i < $length; $i++) {
            Gantid::create([
                'ID'       => $parentID,
                'NO_BUKTI' => $no_bukti,
                'REC'      => $REC[$i],
                'PER'      => $periode,
                'FLAG'     => 'KD',
                'KD_BRG'   => $KD_BRG[$i],
                'KD_BRG2'  => $KD_BRG2[$i],
                'NA_BRG'   => $NA_BRG[$i],
                'KET_UK'   => $KET_UK[$i],
                'KET_KEM'  => $KET_KEM[$i],
                // 'KET'      => $KET[$i],
                'CBG'      => $cbg,
                'USRNM'    => Auth::user()->username,
                'TG_SMP'   => Carbon::now(),
            ]);
        }

        return redirect('/gsub')->with('status', 'Data baru berhasil ditambahkan');	
		
	}

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request , Ganti $gsub)
    {

        $tipx = $request->tipx;

		$idx = $request->idx;
					
        $cbg = Auth::user()->CBG;
		
		if ( $idx =='0' && $tipx=='undo'  )
	    {
			$tipx ='top';
			
		   }
		   
		if ($tipx=='search') {
			
		   	
    	   $buktix = $request->buktix;
		   
		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from ganti
		                 where NO_BUKTI = '$buktix'						 
		                 ORDER BY NO_BUKTI ASC  LIMIT 1" );
						 
			
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0; 
			  }
		
					
		}
		
		if ($tipx=='top') {
			
		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from ganti
		                 ORDER BY NO_BUKTI ASC  LIMIT 1" );
					 
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			  }
			else
			{
				$idx = 0; 
			  }
			  
		}
		
		
		if ($tipx=='prev' ) {
			
    	   $buktix = $request->buktix;
			
		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from ganti
		                 where NO_BUKTI < 
					    '$buktix' ORDER BY NO_BUKTI DESC LIMIT 1" );
			

			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			}
			else
			{
				$idx = $idx; 
			}

		}
		if ($tipx=='next' ) {
			
				
      	   $buktix = $request->buktix;
	   
		   $bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from ganti
		                 where NO_BUKTI > 
					    '$buktix' ORDER BY NO_BUKTI ASC LIMIT 1" );
					 
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			}
			else
			{
				$idx = $idx; 
			}
			  
			
		}

		if ($tipx=='bottom') {
		  
    		$bingco = DB::SELECT("SELECT NO_ID, NO_BUKTI from ganti
		              ORDER BY NO_BUKTI DESC  LIMIT 1" );
					 
			if(!empty($bingco)) 
			{
				$idx = $bingco[0]->NO_ID;
			}
			else
			{
				$idx = 0; 
			}
			  
			
		}


		if ( $tipx=='undo' || $tipx=='search' )
	    {
        
			$tipx ='edit';
			
		   }
		
		//   $kd_brg = $brg->KD_BRG; 
	
	  	if ( $idx != 0 ) 
		{
			$gsub = Ganti::where('NO_ID', $idx )->first();	
	    }
		else
		{
            $gsub = new Ganti();			 
		}

        // dd($sub);
        $no_idx = $gsub->NO_ID;
        $detailGsub = DB::SELECT("SELECT * FROM gantid WHERE ID = '$no_idx'");
		$data = [
					'header' => $gsub,
                    'detail' => $detailGsub
			    ];			
                
        return view('master_ganti_sub_item.edit', $data)->with(['tipx' => $tipx, 'idx' => $idx ]);		
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */


    public function update(Request $request, Ganti $gsub)
    {

        $this->validate(
            $request,
            [

                'TGL'       => 'required'
            ]
        );

        $cbg     = Auth::user()->CBG;
        $periode = $request->session()->get('periode')['bulan'] . '/' . $request->session()->get('periode')['tahun'];
		$parentID = $gsub->NO_ID;

        $gsub->update(
            [
                'TGL'    => date('Y-m-d', strtotime($request['TGL'])),
                'NOTES'  => $request['NOTES'] ?? '',
                'USRNM'  => Auth::user()->username,
                'TG_SMP' => Carbon::now()
            ]
        );

		$no_buktix = $request->NO_BUKTI;

        // Update Detail
        $length = sizeof($request->input('REC'));
        $NO_ID  = $request->input('NO_ID');

        $REC    = $request->input('REC');
        $KD_BRG   = $request->input('KD_BRG');
        $NA_BRG  = $request->input('NA_BRG');
        $KET_UK   = $request->input('KET_UK');
        $KET_KEM  = $request->input('KET_KEM');
        $KD_BRG2  = $request->input('KD_BRG2');

        // Delete yang NO_ID tidak ada di input
        $query = DB::table('gantid')->where('NO_BUKTI', $no_buktix)->whereNotIn('NO_ID',  $NO_ID)->delete();

        // Update / Insert
        for ($i = 0; $i < $length; $i++) {
            // Insert jika NO_ID baru
            if ($NO_ID[$i] == 'new') {
                $insert = Gantid::create(
                    [
                        'ID' 		 => $parentID, 
                        'NO_BUKTI'   => $no_buktix,
                        'REC'        => $REC[$i],
                        'PER'        => $periode,
                        'FLAG'     => 'KD',
                        'KD_BRG'   => $KD_BRG[$i],
                        'KD_BRG2'  => $KD_BRG2[$i],
                        'NA_BRG'   => $NA_BRG[$i],
                        'KET_UK'   => $KET_UK[$i],
                        'KET_KEM'  => $KET_KEM[$i],
                        // 'KET'      => $KET[$i],
                        'CBG'      => $cbg,
                        'USRNM'    => Auth::user()->username,
                        'TG_SMP'   => Carbon::now(),
                    ]
                );
            } else {
                // Update jika NO_ID sudah ada
                $update = Gantid::updateOrCreate(
                    [
                        'NO_BUKTI'  => $no_buktix,
                        'NO_ID'     => (int) str_replace(',', '', $NO_ID[$i])
                    ],

                    [
                        'REC'        => $REC[$i],
                        'PER'        => $periode,
                        'FLAG'     => 'KD',
                        'KD_BRG'   => $KD_BRG[$i],
                        'KD_BRG2'  => $KD_BRG2[$i],
                        'NA_BRG'   => $NA_BRG[$i],
                        'KET_UK'   => $KET_UK[$i],
                        'KET_KEM'  => $KET_KEM[$i],
                        // 'KET'      => $KET[$i],
                        'CBG'      => $cbg,
                        'USRNM'    => Auth::user()->username,
                        'TG_SMP'   => Carbon::now(),
                    ]
                );
            }
        }
		
		$gsub = Ganti::where('NO_BUKTI', $no_buktix )->first();
		
        
        return redirect('/gsub')->with('status', 'Data berhasil diupdate');
		
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\Rute  $rute
     * @return \Illuminate\Http\Response
     */

    // ganti 22

    public function destroy(Request $request , Ganti $gsub)
    {

        DB::table('gantid')->where('ID', $gsub->NO_ID)->delete();
        $deleteGsub = Ganti::find($gsub->NO_ID);

        $deleteGsub->delete();

        return redirect('/gsub')->with('status', 'Data berhasil dihapus');
    }

}