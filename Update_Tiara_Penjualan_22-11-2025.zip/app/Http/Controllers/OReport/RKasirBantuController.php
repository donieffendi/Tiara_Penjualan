<?php

namespace App\Http\Controllers\OReport;

use App\Http\Controllers\Controller;
use App\Models\Master\Cbg;
use App\Models\Master\Perid;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

include_once base_path() . "/vendor/simitgroup/phpjasperxml/version/1.1/PHPJasperXML.inc.php";

use PHPJasperXML;

class RKasirBantuController extends Controller
{
    /**
     * Halaman utama report - Route: /rkasirbantu
     */
    public function report()
    {
        $cbg = Cbg::groupBy('CBG')->get();
        $per = Perid::query()->get();

        // Initialize session variables
        session()->put('filter_cbg', '');
        session()->put('filter_kodes', '');
        session()->put('filter_periode', '');

        return view('oreport_kasirbantu.report')->with([
            'cbg' => $cbg,
            'per' => $per,
            'hasilKasirBantu' => []
        ]);
    }

    /**
     * Get data kasir bantu report - Route: /get-kasirbantu-report
     * Menyesuaikan dengan route name yang ada
     */
    public function getKasirBantuReport(Request $request)
    {
        $cbg = Cbg::groupBy('CBG')->get();
        $per = Perid::query()->get();

        // Set filter values to session
        session()->put('filter_cbg', $request->cbg ?? '');
        session()->put('filter_kodes', $request->kodes ?? '');
        session()->put('filter_periode', $request->periode ?? '');

        $hasilKasirBantu = [];

        if (!empty($request->cbg)) {
            try {
                $hasilKasirBantu = $this->getKasirBantuData(
                    $request->cbg,
                    $request->kodes ?? '',
                    $request->periode ?? ''
                );
            } catch (\Exception $e) {
                Log::error('Error in getKasirBantuReport: ' . $e->getMessage());
                return view('oreport_kasirbantu.report')->with([
                    'cbg' => $cbg,
                    'per' => $per,
                    'hasilKasirBantu' => [],
                    'error' => $e->getMessage()
                ]);
            }
        }

        return view('oreport_kasirbantu.report')->with([
            'cbg' => $cbg,
            'per' => $per,
            'hasilKasirBantu' => $hasilKasirBantu
        ]);
    }

    /**
     * Generate laporan Jasper - Route: /jasper-kasirbantu-report
     * Implementasi dari logika Delphi untuk generate report
     */
    public function jasperKasirBantuReport(Request $request)
    {
        try {
            $file = 'kasirbantu'; // Nama file jasper report
            $PHPJasperXML = new PHPJasperXML();
            $PHPJasperXML->load_xml_file(base_path() . ('/app/reportc01/phpjasperxml/' . $file . '.jrxml'));

            // Set session values
            session()->put('filter_cbg', $request->cbg ?? '');
            session()->put('filter_kodes', $request->kodes ?? '');
            session()->put('filter_periode', $request->periode ?? '');

            $data = [];

            if (!empty($request->cbg)) {
                $hasilKasirBantu = $this->getKasirBantuData(
                    $request->cbg,
                    $request->kodes ?? '',
                    $request->periode ?? ''
                );

                foreach ($hasilKasirBantu as $item) {
                    $data[] = [
                        'CBG' => $item['CBG'] ?? '',
                        'KODES' => $item['KODES'] ?? '',
                        'NAMA_KASIR' => $item['NAMA_KASIR'] ?? '',
                        'PERIODE' => $item['PERIODE'] ?? '',
                        'TOTAL_TRANSAKSI' => $item['TOTAL_TRANSAKSI'] ?? 0,
                        'TOTAL_AMOUNT' => $item['TOTAL_AMOUNT'] ?? 0,
                        'TANGGAL_CETAK' => date('Y-m-d H:i:s')
                    ];
                }
            }

            $PHPJasperXML->setData($data);

            // Set parameters untuk report
            $PHPJasperXML->arrayParameter = [
                "CBG" => $request->cbg ?? '',
                "KODES" => $request->kodes ?? '',
                "PERIODE" => $request->periode ?? '',
                "TANGGAL_CETAK" => date('d/m/Y H:i:s'),
                "NAMA_TOKO" => $this->getNamaToko($request->cbg ?? '')
            ];

            ob_end_clean();
            $PHPJasperXML->outpage("I"); // I = Inline view, D = Download, F = Save to file

        } catch (\Exception $e) {
            Log::error('Error in jasperKasirBantuReport: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Mengimplementasikan logika dari procedure Delphi untuk mendapatkan data kasir bantu
     * Disesuaikan dengan kebutuhan laporan kasir bantu
     */
    private function getKasirBantuData($cbg, $kodes = '', $periode = '')
    {
        try {
            // Validasi input dasar
            if (empty($cbg)) {
                throw new \Exception('Cabang harus diisi!');
            }

            // Validate cabang exists in toko table
            $cabangExists = DB::table('tgz.toko')
                ->where('KODE', $cbg)
                ->whereIn('STA', ['MA', 'CB', 'DC'])
                ->exists();

            if (!$cabangExists) {
                throw new \Exception('Cabang tidak valid atau tidak aktif!');
            }

            // Base query untuk kasir bantu
            // Implementasi logika dari Delphi disesuaikan dengan struktur database Laravel
            $query = DB::table("{$cbg}.kasir_bantu as kb")
                ->select([
                    DB::raw("'{$cbg}' as CBG"),
                    'kb.KODE_KASIR as KODES',
                    'kb.NAMA_KASIR',
                    DB::raw("COALESCE(kb.PERIODE, '') as PERIODE"),
                    DB::raw("COUNT(kb.NO_TRANSAKSI) as TOTAL_TRANSAKSI"),
                    DB::raw("COALESCE(SUM(kb.TOTAL_AMOUNT), 0) as TOTAL_AMOUNT"),
                    'kb.TGL_INPUT',
                    'kb.USER_INPUT'
                ]);

            // Apply filter berdasarkan kode kasir jika ada
            if (!empty($kodes)) {
                $query->where('kb.KODE_KASIR', 'like', '%' . trim($kodes) . '%');
            }

            // Apply filter berdasarkan periode jika ada
            if (!empty($periode)) {
                $query->where('kb.PERIODE', $periode);
            }

            // Group by untuk aggregasi data
            $query->groupBy([
                'kb.KODE_KASIR',
                'kb.NAMA_KASIR',
                'kb.PERIODE',
                'kb.TGL_INPUT',
                'kb.USER_INPUT'
            ]);

            // Order by sesuai logika Delphi
            $query->orderBy('kb.KODE_KASIR', 'ASC')
                ->orderBy('kb.PERIODE', 'DESC');

            $hasilData = $query->get();

            // Transform data sesuai format yang dibutuhkan
            $result = [];
            foreach ($hasilData as $item) {
                $result[] = [
                    'CBG' => $item->CBG,
                    'KODES' => $item->KODES,
                    'NAMA_KASIR' => $item->NAMA_KASIR,
                    'PERIODE' => $item->PERIODE,
                    'TOTAL_TRANSAKSI' => (int)$item->TOTAL_TRANSAKSI,
                    'TOTAL_AMOUNT' => (float)$item->TOTAL_AMOUNT,
                    'TGL_INPUT' => $item->TGL_INPUT,
                    'USER_INPUT' => $item->USER_INPUT
                ];
            }

            // Log activity
            $this->logActivity('get_kasir_bantu', $cbg, $kodes, count($result));

            return $result;
        } catch (\Exception $e) {
            Log::error('Error in getKasirBantuData: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Helper functions dari Delphi - tetap dipertahankan untuk kompatibilitas
     */
    private function leftStr($string, $count)
    {
        return substr($string, 0, $count);
    }

    private function rightStr($string, $count)
    {
        $length = strlen($string);
        if ($length < $count) {
            return $string;
        }
        return substr($string, $length - $count, $count);
    }

    /**
     * Get daftar kasir untuk dropdown
     * Implementasi untuk mendukung pencarian kasir
     */
    public function getKasirList($cbg)
    {
        try {
            if (empty($cbg)) {
                return [];
            }

            $query = "
                SELECT DISTINCT KODE_KASIR, NAMA_KASIR
                FROM {$cbg}.kasir_bantu
                WHERE KODE_KASIR IS NOT NULL
                  AND KODE_KASIR != ''
                  AND NAMA_KASIR IS NOT NULL
                ORDER BY KODE_KASIR ASC
            ";

            return DB::select($query);
        } catch (\Exception $e) {
            Log::error('Error in getKasirList: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get daftar periode yang tersedia
     */
    public function getPeriodeList($cbg)
    {
        try {
            if (empty($cbg)) {
                return [];
            }

            $query = "
                SELECT DISTINCT PERIODE
                FROM {$cbg}.kasir_bantu
                WHERE PERIODE IS NOT NULL
                  AND PERIODE != ''
                ORDER BY PERIODE DESC
            ";

            return DB::select($query);
        } catch (\Exception $e) {
            Log::error('Error in getPeriodeList: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get daftar cabang yang valid
     */
    public function getCabangList()
    {
        try {
            $query = "
                SELECT KODE, NAMA, STA
                FROM tgz.toko
                WHERE STA IN ('MA', 'CB', 'DC')
                ORDER BY NO_ID ASC
            ";

            return DB::select($query);
        } catch (\Exception $e) {
            Log::error('Error in getCabangList: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Export ke Excel
     */
    public function exportToExcel(Request $request)
    {
        try {
            if (empty($request->cbg)) {
                return response()->json(['error' => 'Cabang harus diisi!'], 400);
            }

            $data = $this->getKasirBantuData(
                $request->cbg,
                $request->kodes ?? '',
                $request->periode ?? ''
            );

            if (empty($data)) {
                return response()->json(['message' => 'Tidak ada data untuk diekspor'], 200);
            }

            // Generate filename
            $filename = 'kasir_bantu_' . $request->cbg;
            if (!empty($request->kodes)) {
                $filename .= '_' . str_replace(['/', '\\', ' '], '_', $request->kodes);
            }
            if (!empty($request->periode)) {
                $filename .= '_' . str_replace(['/', '\\', ' '], '_', $request->periode);
            }
            $filename .= '_' . date('YmdHis') . '.xlsx';

            return response()->json(['success' => true, 'filename' => $filename]);
        } catch (\Exception $e) {
            Log::error('Error in exportToExcel: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Search kasir bantu dengan AJAX
     */
    public function searchKasirBantu(Request $request)
    {
        try {
            $cbg = $request->cbg;
            $kodes = trim($request->kodes ?? '');
            $periode = trim($request->periode ?? '');

            if (empty($cbg)) {
                return response()->json(['error' => 'Cabang harus diisi!'], 400);
            }

            $data = $this->getKasirBantuData($cbg, $kodes, $periode);

            return response()->json([
                'success' => true,
                'data' => $data,
                'total_records' => count($data)
            ]);
        } catch (\Exception $e) {
            Log::error('Error in searchKasirBantu: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Validasi input parameters
     */
    private function validateInput($cbg, $kodes = '', $periode = '')
    {
        if (empty($cbg)) {
            throw new \Exception('Cabang harus diisi!');
        }

        // Validate cabang format
        if (!preg_match('/^[A-Z0-9]+$/', $cbg)) {
            throw new \Exception('Format cabang tidak valid!');
        }

        // Validate kodes format jika diisi
        if (!empty($kodes) && !preg_match('/^[A-Z0-9\-_\/\s]+$/i', $kodes)) {
            throw new \Exception('Format kode kasir tidak valid!');
        }

        // Validate periode format jika diisi
        if (!empty($periode) && !preg_match('/^[0-9\-\/]+$/', $periode)) {
            throw new \Exception('Format periode tidak valid!');
        }

        return true;
    }

    /**
     * Helper method untuk logging
     */
    private function logActivity($action, $cbg, $kodes = '', $recordCount = 0)
    {
        Log::info("KasirBantu: {$action}", [
            'cbg' => $cbg,
            'kodes' => $kodes,
            'record_count' => $recordCount,
            'user' => auth()->user()->id ?? 'system',
            'timestamp' => now()
        ]);
    }

    /**
     * Get nama toko berdasarkan kode cabang
     */
    public function getNamaToko($cbg)
    {
        try {
            $result = DB::table('tgz.toko')
                ->select('NA_TOKO')
                ->where('KODE', $cbg)
                ->first();

            return $result ? $result->NA_TOKO : '';
        } catch (\Exception $e) {
            Log::error('Error in getNamaToko: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Method untuk mendukung AJAX request dari view
     */
    public function ajaxGetKasirBantu(Request $request)
    {
        try {
            $cbg = $request->get('cbg');
            $kodes = $request->get('kodes', '');
            $periode = $request->get('periode', '');

            if (empty($cbg)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Parameter cabang tidak boleh kosong',
                    'data' => []
                ]);
            }

            $data = $this->getKasirBantuData($cbg, $kodes, $periode);

            return response()->json([
                'success' => true,
                'message' => 'Data berhasil diambil',
                'data' => $data,
                'total' => count($data)
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'data' => []
            ]);
        }
    }

    /**
     * Method untuk preview data sebelum print
     */
    public function previewKasirBantu(Request $request)
    {
        try {
            $cbg = $request->cbg;
            $kodes = $request->kodes ?? '';
            $periode = $request->periode ?? '';

            if (empty($cbg)) {
                return redirect()->back()->with('error', 'Cabang harus diisi!');
            }

            $data = $this->getKasirBantuData($cbg, $kodes, $periode);
            $namaToko = $this->getNamaToko($cbg);

            return view('oreport_kasirbantu.preview')->with([
                'data' => $data,
                'cbg' => $cbg,
                'kodes' => $kodes,
                'periode' => $periode,
                'namaToko' => $namaToko,
                'totalRecords' => count($data)
            ]);
        } catch (\Exception $e) {
            Log::error('Error in previewKasirBantu: ' . $e->getMessage());
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Get summary data untuk dashboard atau report summary
     */
    public function getSummaryKasirBantu($cbg, $periode = '')
    {
        try {
            if (empty($cbg)) {
                return [];
            }

            $query = DB::table("{$cbg}.kasir_bantu as kb")
                ->select([
                    DB::raw("COUNT(DISTINCT kb.KODE_KASIR) as TOTAL_KASIR"),
                    DB::raw("COUNT(kb.NO_TRANSAKSI) as TOTAL_TRANSAKSI"),
                    DB::raw("COALESCE(SUM(kb.TOTAL_AMOUNT), 0) as TOTAL_AMOUNT"),
                    DB::raw("COALESCE(AVG(kb.TOTAL_AMOUNT), 0) as AVG_AMOUNT")
                ]);

            if (!empty($periode)) {
                $query->where('kb.PERIODE', $periode);
            }

            $result = $query->first();

            return [
                'TOTAL_KASIR' => (int)$result->TOTAL_KASIR,
                'TOTAL_TRANSAKSI' => (int)$result->TOTAL_TRANSAKSI,
                'TOTAL_AMOUNT' => (float)$result->TOTAL_AMOUNT,
                'AVG_AMOUNT' => (float)$result->AVG_AMOUNT
            ];
        } catch (\Exception $e) {
            Log::error('Error in getSummaryKasirBantu: ' . $e->getMessage());
            return [];
        }
    }
}