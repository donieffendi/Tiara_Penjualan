<?php

namespace App\Http\Controllers\OTransaksi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class TOrderKoreksiPembelianController extends Controller
{
    public function index()
    {
        // Set flag dari CBG user jika belum ada di session
        if (!session('flag')) {
            $flag = Auth::user()->CBG ?? null;
            if ($flag) {
                session(['flag' => $flag]);
            }
        }

        return view('otranskasi_order_koreksi_pembelian.index');
    }

    public function getOrderKoreksiPembelian(Request $request)
    {
        try {
            $periodeSession = session('periode');
            $flag = session('flag');

            // Jika flag tidak ada di session, gunakan CBG dari user yang login
            if (!$flag) {
                $flag = Auth::user()->CBG ?? null;
                if ($flag) {
                    session(['flag' => $flag]);
                }
            }

            if (!$periodeSession) {
                Log::warning('TOrderKoreksiPembelian: Periode belum diset');
                return response()->json([
                    'error' => 'Periode belum diset',
                    'draw' => intval($request->input('draw', 0)),
                    'recordsTotal' => 0,
                    'recordsFiltered' => 0,
                    'data' => []
                ], 200);
            }

            if (!$flag) {
                Log::warning('TOrderKoreksiPembelian: Cabang (flag) belum diset');
                return response()->json([
                    'error' => 'Cabang (flag) belum diset',
                    'draw' => intval($request->input('draw', 0)),
                    'recordsTotal' => 0,
                    'recordsFiltered' => 0,
                    'data' => []
                ], 200);
            }

            // Convert periode array to string format MM/YYYY
            $periode = str_pad($periodeSession['bulan'], 2, '0', STR_PAD_LEFT) . '/' . $periodeSession['tahun'];

            $queryStr = "SELECT NO_BUKTI, TGL, PER, KODES, NAMAS, TOTAL_QTY, FLAG, TG_SMP, CBG,
                    EXP, OPERATOR, USRNM, NOTES, total, LPH1, LPH2, HARI, SUB1, SUB2
             FROM khusus
             WHERE per=? AND flag='BL' AND cbg=?
             GROUP BY no_bukti
             ORDER BY NO_BUKTI DESC";

            Log::info('TOrderKoreksiPembelian Query:', [
                'query' => $queryStr,
                'params' => [$periode, $flag]
            ]);

            $query = DB::select($queryStr, [$periode, $flag]);

            Log::info('TOrderKoreksiPembelian: Data retrieved', ['count' => count($query)]);

            return Datatables::of(collect($query))
                ->addIndexColumn()
                ->editColumn('TGL', function ($row) {
                    return $row->TGL ? date('d-m-Y', strtotime($row->TGL)) : '';
                })
                ->editColumn('TG_SMP', function ($row) {
                    return $row->TG_SMP ? date('d-m-Y H:i', strtotime($row->TG_SMP)) : '';
                })
                ->editColumn('TOTAL_QTY', function ($row) {
                    return number_format($row->TOTAL_QTY, 0, ',', '.');
                })
                ->editColumn('total', function ($row) {
                    return number_format($row->total, 2, ',', '.');
                })
                ->addColumn('action', function ($row) {
                    if (
                        Auth::user()->divisi == "programmer" || Auth::user()->divisi == "owner" ||
                        Auth::user()->divisi == "assistant" || Auth::user()->divisi == "accounting"
                    ) {
                        $btnEdit = '<a class="dropdown-item" href="' . route('torderkoreksipembelian.edit', ['no_bukti' => $row->NO_BUKTI]) . '">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>';
                        $btnDelete = '<a class="dropdown-item btn-delete" data-id="' . $row->NO_BUKTI . '">
                                        <i class="fa fa-trash"></i> Delete
                                      </a>';
                        $btnPrint = '<a class="dropdown-item btn-print" data-id="' . $row->NO_BUKTI . '">
                                        <i class="fa fa-print"></i> Print
                                      </a>';

                        $actionBtn = '
                        <div class="dropdown show" style="text-align: center">
                            <a class="btn btn-secondary dropdown-toggle btn-sm" href="#" role="button"
                               id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bars"></i>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                ' . $btnEdit . '
                                ' . $btnPrint . '
                                <hr>
                                ' . $btnDelete . '
                            </div>
                        </div>';

                        return $actionBtn;
                    }
                    return '';
                })
                ->rawColumns(['action'])
                ->make(true);
        } catch (\Exception $e) {
            Log::error('TOrderKoreksiPembelian Error in getData: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'error' => 'Terjadi kesalahan: ' . $e->getMessage(),
                'draw' => intval($request->input('draw', 0)),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => []
            ], 200);
        }
    }

    public function edit(Request $request)
    {
        try {
            $no_bukti = $request->get('no_bukti');
            $status = $request->get('status', 'simpan');
            $periodeSession = session('periode');
            $flag = session('flag') ?? Auth::user()->CBG;

            if (!$periodeSession) {
                Log::warning('TOrderKoreksiPembelian Edit: Periode belum diset');
                return redirect()->back()->with('error', 'Periode belum diset');
            }

            // Convert periode array to string format MM/YYYY
            $periode = str_pad($periodeSession['bulan'], 2, '0', STR_PAD_LEFT) . '/' . $periodeSession['tahun'];

            $data = [
                'no_bukti' => '+',
                'status' => $status,
                'header' => null,
                'detail' => [],
                'periode' => $periode,
                'cbg' => $flag
            ];

            if ($status == 'edit' && $no_bukti) {
                $queryStr = "SELECT NO_BUKTI, TGL, PER, KODES, NAMAS, TOTAL_QTY, FLAG, TG_SMP, CBG,
                        EXP, OPERATOR, USRNM, NOTES, total, LPH1, LPH2, HARI, SUB1, SUB2
                 FROM khusus
                 WHERE no_bukti=? AND flag='BL'
                 GROUP BY no_bukti
                 ORDER BY NO_BUKTI";

                Log::info('TOrderKoreksiPembelian Edit Query Header:', [
                    'query' => $queryStr,
                    'params' => [$no_bukti]
                ]);

                $header = DB::select($queryStr, [$no_bukti]);

                if (!empty($header)) {
                    $detailQueryStr = "SELECT * FROM KHUSUSD
                     WHERE NO_BUKTI = ?
                     ORDER BY REC";

                    Log::info('TOrderKoreksiPembelian Edit Query Detail:', [
                        'query' => $detailQueryStr,
                        'params' => [$no_bukti]
                    ]);

                    $detail = DB::select($detailQueryStr, [$no_bukti]);

                    $data['header'] = $header[0];
                    $data['detail'] = $detail;
                    $data['no_bukti'] = $no_bukti;

                    Log::info('TOrderKoreksiPembelian: Data loaded for edit', [
                        'no_bukti' => $no_bukti,
                        'detail_count' => count($detail)
                    ]);
                }
            }

            return view('otranskasi_order_koreksi_pembelian.edit', $data);
        } catch (\Exception $e) {
            Log::error('TOrderKoreksiPembelian Error in edit: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'tgl' => 'required|date',
            'kodes' => 'required',
            'details' => 'required|array|min:1'
        ]);

        DB::beginTransaction();

        try {
            $no_bukti = trim($request->no_bukti);
            $status = $request->status;
            $periodeSession = session('periode');
            $flag = session('flag') ?? Auth::user()->CBG;
            $username = Auth::user()->username ?? Auth::user()->name ?? 'system';

            if (!$periodeSession) {
                Log::warning('TOrderKoreksiPembelian Store: Periode belum diset');
                return response()->json([
                    'success' => false,
                    'message' => 'Periode belum diset'
                ], 400);
            }

            // Convert periode array to string format MM/YYYY
            $periode = str_pad($periodeSession['bulan'], 2, '0', STR_PAD_LEFT) . '/' . $periodeSession['tahun'];

            $tgl = Carbon::parse($request->tgl);
            $monthz = str_pad($tgl->month, 2, '0', STR_PAD_LEFT);
            $yearz = $tgl->year;

            $periode_month = $periodeSession['bulan'];
            $periode_year = $periodeSession['tahun'];

            Log::info('TOrderKoreksiPembelian Store: Validating periode', [
                'tgl_month' => $monthz,
                'tgl_year' => $yearz,
                'periode_month' => $periode_month,
                'periode_year' => $periode_year
            ]);

            if ($monthz != str_pad($periode_month, 2, '0', STR_PAD_LEFT)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Bulan tidak sesuai dengan periode'
                ], 400);
            }

            if ($yearz != $periode_year) {
                return response()->json([
                    'success' => false,
                    'message' => 'Tahun tidak sesuai dengan periode'
                ], 400);
            }

            $total_qty = 0;
            $total_amount = 0;

            foreach ($request->details as $detail) {
                if (!empty($detail['kd_brg'])) {
                    $total_qty += floatval($detail['qty'] ?? 0);
                    $total_amount += floatval($detail['total'] ?? 0);
                }
            }

            if ($status == 'simpan') {
                if ($no_bukti == '+') {
                    $no_bukti = $this->generateNoBukti($periodeSession, $flag);
                    Log::info('TOrderKoreksiPembelian: Generated NO_BUKTI', ['no_bukti' => $no_bukti]);
                }

                $insertQuery = "INSERT INTO KHUSUS (NO_BUKTI, TGL, PER, KODES, NAMAS, TOTAL_QTY, FLAG, TG_SMP, CBG,
                                         EXP, OPERATOR, USRNM, NOTES, total, LPH1, LPH2, HARI, SUB1, SUB2)
                     VALUES (?, ?, ?, ?, ?, ?, 'BL', NOW(), ?, ?, 'C', ?, ?, ?, ?, ?, ?, ?, ?)";

                $insertParams = [
                    $no_bukti,
                    $request->tgl,
                    $periode,
                    $request->kodes,
                    $request->namas ?? '',
                    $total_qty,
                    $flag,
                    '',
                    $username,
                    $request->notes ?? '',
                    $total_amount,
                    floatval($request->lph1 ?? 0),
                    floatval($request->lph2 ?? 0),
                    floatval($request->hari ?? 0),
                    $request->sub1 ?? '',
                    $request->sub2 ?? ''
                ];

                Log::info('TOrderKoreksiPembelian Insert Header:', [
                    'query' => $insertQuery,
                    'params' => $insertParams
                ]);

                DB::statement($insertQuery, $insertParams);
            } else {
                $updateQuery = "UPDATE KHUSUS SET TGL=?, KODES=?, NAMAS=?, NOTES=?, TOTAL_QTY=?, TOTAL=?, FLAG='BL',
                            CBG=?, EXP=?, OPERATOR='C', LPH1=?, LPH2=?, HARI=?, SUB1=?, SUB2=?,
                            USRNM=?, TG_SMP=NOW(), posted=0
                     WHERE NO_BUKTI=?";

                $updateParams = [
                    $request->tgl,
                    $request->kodes,
                    $request->namas ?? '',
                    $request->notes ?? '',
                    $total_qty,
                    $total_amount,
                    $flag,
                    '',
                    floatval($request->lph1 ?? 0),
                    floatval($request->lph2 ?? 0),
                    floatval($request->hari ?? 0),
                    $request->sub1 ?? '',
                    $request->sub2 ?? '',
                    $username,
                    $no_bukti
                ];

                Log::info('TOrderKoreksiPembelian Update Header:', [
                    'query' => $updateQuery,
                    'params' => $updateParams
                ]);

                DB::statement($updateQuery, $updateParams);
            }

            $header_id_result = DB::select("SELECT no_id FROM khusus WHERE no_bukti=?", [$no_bukti]);
            $id = $header_id_result[0]->no_id ?? 0;

            Log::info('TOrderKoreksiPembelian: Header ID', ['id' => $id]);

            if ($status == 'edit') {
                $existing_details = DB::select("SELECT no_id FROM khususd WHERE id=?", [$id]);

                Log::info('TOrderKoreksiPembelian: Processing existing details', [
                    'count' => count($existing_details)
                ]);

                foreach ($existing_details as $existing) {
                    $found = false;
                    foreach ($request->details as $detail) {
                        if (isset($detail['no_id']) && $detail['no_id'] == $existing->no_id) {
                            $updateDetailQuery = "UPDATE KHUSUSD SET REC=?, KODES=?, KD_BRG=?, NA_BRG=?, QTYPO=?, QTYBRG=?, LPH=?,
                                        ket_kem=?, QTY=?, HARGA=?, TOTAL=?, NOTES=?, kemasan=?, ket_uk=?
                                 WHERE NO_ID=?";

                            $updateDetailParams = [
                                intval($detail['rec'] ?? 1),
                                trim($detail['kodes'] ?? ''),
                                trim($detail['kd_brg'] ?? ''),
                                trim($detail['na_brg'] ?? ''),
                                floatval($detail['qtypo'] ?? 0),
                                floatval($detail['qtybrg'] ?? 0),
                                floatval($detail['lph'] ?? 0),
                                $detail['ket_kem'] ?? '',
                                floatval($detail['qty'] ?? 0),
                                floatval($detail['harga'] ?? 0),
                                floatval($detail['total'] ?? 0),
                                trim($detail['notes'] ?? ''),
                                floatval($detail['kemasan'] ?? 0),
                                $detail['ket_uk'] ?? '',
                                $existing->no_id
                            ];

                            Log::info('TOrderKoreksiPembelian Update Detail:', [
                                'query' => $updateDetailQuery,
                                'params' => $updateDetailParams
                            ]);

                            DB::statement($updateDetailQuery, $updateDetailParams);
                            $found = true;
                            break;
                        }
                    }

                    if (!$found) {
                        Log::info('TOrderKoreksiPembelian Delete Detail:', ['no_id' => $existing->no_id]);
                        DB::statement("DELETE FROM KHUSUSD WHERE NO_ID=?", [$existing->no_id]);
                    }
                }
            }

            $rec = 1;
            foreach ($request->details as $detail) {
                if (!empty($detail['kd_brg'])) {
                    if (!isset($detail['no_id']) || $detail['no_id'] == 0) {
                        $insertDetailQuery = "INSERT INTO KHUSUSD (NO_BUKTI, QTYBRG, LPH, KODES, REC, PER, FLAG, KD_BRG, NA_BRG,
                                                   KEMASAN, ket_kem, QTYPO, QTY, HARGA, TOTAL, NOTES, ID, cbg, ket_uk)
                             VALUES (?, ?, ?, ?, ?, ?, 'BL', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                        $insertDetailParams = [
                            $no_bukti,
                            floatval($detail['qtybrg'] ?? 0),
                            floatval($detail['lph'] ?? 0),
                            trim($detail['kodes'] ?? ''),
                            $rec,
                            $periode,
                            trim($detail['kd_brg'] ?? ''),
                            trim($detail['na_brg'] ?? ''),
                            floatval($detail['kemasan'] ?? 0),
                            $detail['ket_kem'] ?? '',
                            floatval($detail['qtypo'] ?? 0),
                            floatval($detail['qty'] ?? 0),
                            floatval($detail['harga'] ?? 0),
                            floatval($detail['total'] ?? 0),
                            trim($detail['notes'] ?? ''),
                            $id,
                            $flag,
                            $detail['ket_uk'] ?? ''
                        ];

                        Log::info('TOrderKoreksiPembelian Insert Detail:', [
                            'query' => $insertDetailQuery,
                            'params' => $insertDetailParams
                        ]);

                        DB::statement($insertDetailQuery, $insertDetailParams);
                    }
                    $rec++;
                }
            }

            Log::info('TOrderKoreksiPembelian Delete SPO:', ['no_bukti' => $no_bukti]);
            DB::statement("DELETE FROM SPO WHERE no_bukti=?", [$no_bukti]);

            DB::commit();

            Log::info('TOrderKoreksiPembelian: Data saved successfully', ['no_bukti' => $no_bukti]);

            return response()->json([
                'success' => true,
                'message' => 'Data berhasil disimpan',
                'no_bukti' => $no_bukti
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TOrderKoreksiPembelian Error in store: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal menyimpan data: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        try {
            DB::beginTransaction();

            Log::info('TOrderKoreksiPembelian Delete: Starting deletion', ['id' => $id]);

            // Get NO_BUKTI for logging
            $header = DB::select("SELECT no_bukti FROM khusus WHERE no_id=?", [$id]);
            $no_bukti = $header[0]->no_bukti ?? 'UNKNOWN';

            // Delete details
            Log::info('TOrderKoreksiPembelian Delete Details:', [
                'query' => "DELETE FROM khususd WHERE id=?",
                'params' => [$id]
            ]);
            DB::statement("DELETE FROM khususd WHERE id=?", [$id]);

            // Delete header
            Log::info('TOrderKoreksiPembelian Delete Header:', [
                'query' => "DELETE FROM khusus WHERE no_id=?",
                'params' => [$id]
            ]);
            DB::statement("DELETE FROM khusus WHERE no_id=?", [$id]);

            DB::commit();

            Log::info('TOrderKoreksiPembelian: Deletion successful', [
                'id' => $id,
                'no_bukti' => $no_bukti
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Data berhasil dihapus'
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TOrderKoreksiPembelian Error in destroy: ' . $e->getMessage(), [
                'id' => $id,
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data: ' . $e->getMessage()
            ], 500);
        }
    }

    public function browse(Request $request)
    {
        try {
            $type = $request->get('type', 'supplier');
            $q = $request->get('q', '');
            $flag = session('flag') ?? Auth::user()->CBG;

            Log::info('TOrderKoreksiPembelian Browse:', [
                'type' => $type,
                'search' => $q,
                'flag' => $flag
            ]);

            if ($type == 'supplier') {
                if (!empty($q)) {
                    $query = "SELECT kodes, namas FROM sup WHERE kodes LIKE ? OR namas LIKE ? ORDER BY kodes LIMIT 50";
                    $params = ["%$q%", "%$q%"];

                    Log::info('TOrderKoreksiPembelian Browse Supplier with search:', [
                        'query' => $query,
                        'params' => $params
                    ]);

                    $data = DB::select($query, $params);
                } else {
                    $query = "SELECT kodes, namas FROM sup ORDER BY kodes LIMIT 50";

                    Log::info('TOrderKoreksiPembelian Browse All Suppliers:', ['query' => $query]);

                    $data = DB::select($query);
                }
            } elseif ($type == 'barang') {
                if (!empty($q)) {
                    $query = "SELECT brg.kd_brg, brg.na_brg, brg.type, brg.ket_uk, brg.ket_kem, brgdt.lph, brg.supp,
                            brgdt.hj, brgdt.hb, brg.namas, brgdt.klk, brg.mo, brg.loc, brgdt.srmin as sr_min,
                            brgdt.srmax as smax_tk, brgdt.dtr, brgdt.smin, brgdt.smax, brgdt.hb, brgdt.kdlaku,
                            brg.sub, brg.kdbar,
                            substr(trim(brg.KET_KEM), ((LOCATE('/', trim(brg.ket_kem))+1))) AS kemasan,
                            IFNULL((SELECT sum(pod.qty) FROM pod WHERE pod.cbg=? AND pod.KD_BRG=brg.KD_BRG GROUP BY pod.KD_BRG), 0) as totalpo,
                            brgdt.AK00+brgdt.GAK00 as saldo
                     FROM brg, brgdt
                     WHERE brg.KD_BRG=brgdt.KD_BRG
                       AND brgdt.yer=year(now())
                       AND brgdt.cbg=?
                       AND (brg.KD_BRG LIKE ? OR brg.NA_BRG LIKE ?)
                     LIMIT 50";

                    $params = [$flag, $flag, "%$q%", "%$q%"];

                    Log::info('TOrderKoreksiPembelian Browse Barang with search:', [
                        'query' => $query,
                        'params' => $params
                    ]);

                    $data = DB::select($query, $params);
                } else {
                    $data = [];
                }
            } else {
                $data = [];
            }

            Log::info('TOrderKoreksiPembelian Browse Result:', ['count' => count($data)]);

            return response()->json($data);
        } catch (\Exception $e) {
            Log::error('TOrderKoreksiPembelian Error in browse: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal mengambil data: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getDetail(Request $request)
    {
        try {
            $type = $request->get('type', 'supplier');
            $flag = session('flag') ?? Auth::user()->CBG;

            Log::info('TOrderKoreksiPembelian GetDetail:', ['type' => $type, 'flag' => $flag]);

            if ($type == 'supplier') {
                $kodes = $request->get('kodes');

                $query = "SELECT kodes, namas FROM sup WHERE kodes=?";
                $params = [$kodes];

                Log::info('TOrderKoreksiPembelian GetDetail Supplier:', [
                    'query' => $query,
                    'params' => $params
                ]);

                $supplier = DB::select($query, $params);

                if (!empty($supplier)) {
                    Log::info('TOrderKoreksiPembelian GetDetail Supplier Found:', ['kodes' => $kodes]);
                    return response()->json([
                        'success' => true,
                        'exists' => true,
                        'data' => $supplier[0]
                    ]);
                }
            } elseif ($type == 'barang') {
                $kd_brg = $request->get('kd_brg');

                $query = "SELECT brg.kd_brg, brg.na_brg, brg.type, brg.ket_uk, brg.ket_kem, brgdt.lph, brg.supp,
                        brgdt.hj, brgdt.hb, brg.namas, brgdt.klk, brg.mo, brg.loc, brgdt.srmin as sr_min,
                        brgdt.srmax as smax_tk, brgdt.dtr, brgdt.smin, brgdt.smax, brgdt.hb, brgdt.kdlaku,
                        brg.sub, brg.kdbar,
                        substr(trim(brg.KET_KEM), ((LOCATE('/', trim(brg.ket_kem))+1))) AS kemasan,
                        IFNULL((SELECT sum(pod.qty) FROM pod WHERE pod.cbg=? AND pod.KD_BRG=brg.KD_BRG GROUP BY pod.KD_BRG), 0) as totalpo,
                        brgdt.AK00+brgdt.GAK00 as saldo
                 FROM brg, brgdt
                 WHERE brg.KD_BRG=brgdt.KD_BRG
                   AND brgdt.yer=year(now())
                   AND brgdt.cbg=?
                   AND BRG.KD_BRG=?";

                $params = [$flag, $flag, $kd_brg];

                Log::info('TOrderKoreksiPembelian GetDetail Barang:', [
                    'query' => $query,
                    'params' => $params
                ]);

                $barang = DB::select($query, $params);

                if (!empty($barang)) {
                    Log::info('TOrderKoreksiPembelian GetDetail Barang Found:', ['kd_brg' => $kd_brg]);
                    return response()->json([
                        'success' => true,
                        'exists' => true,
                        'data' => $barang[0]
                    ]);
                }
            }

            Log::warning('TOrderKoreksiPembelian GetDetail: Data not found', ['type' => $type]);

            return response()->json([
                'success' => true,
                'exists' => false,
                'data' => null
            ]);
        } catch (\Exception $e) {
            Log::error('TOrderKoreksiPembelian Error in getDetail: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal mengambil detail: ' . $e->getMessage()
            ], 500);
        }
    }

    public function printOrderKoreksiPembelian(Request $request)
    {
        try {
            $no_bukti = $request->no_bukti;
            $flag = session('flag') ?? Auth::user()->CBG;

            Log::info('TOrderKoreksiPembelian Print:', [
                'no_bukti' => $no_bukti,
                'flag' => $flag
            ]);

            // Check if already posted
            $postedQuery = "SELECT posted FROM khusus WHERE no_bukti=?";
            $postedParams = [$no_bukti];

            Log::info('TOrderKoreksiPembelian Check Posted Status:', [
                'query' => $postedQuery,
                'params' => $postedParams
            ]);

            $posted = DB::select($postedQuery, $postedParams);

            if (!empty($posted) && $posted[0]->posted == 0) {
                Log::info('TOrderKoreksiPembelian: Document not posted yet, inserting to SPO');

                $insertSPOQuery = "INSERT INTO SPO(no_bukti, tgl, per, kodes, namas, notes, flag, total, nett, type, tg_smp, CBG,
                                 KET_KEM, kemasan, NA_BRG, KD_BRG, QTY, HARGA, SUB, KDBAR, KET, TGO, TGL_MULAI)
                 SELECT khusus.NO_BUKTI, date(now()), khusus.per, khususd.kodes, khusus.namas, KHUSUS.notes, KHUSUS.FLAG,
                        KHUSUSd.total, KHUSUSd.total, KHUSUS.type, now(), KHUSUS.cbg, KHUSUSd.ket_kem, khususd.kemasan,
                        khususd.NA_BRG, khususd.KD_BRG, khususd.qty, khususd.harga,
                        left(trim(khususd.kd_brg), 3) as sub, right(trim(khususd.kd_brg), 4) as kdbar,
                        khusus.ket, date(now()), date(now())
                 FROM khusus, khususd
                 WHERE khusus.no_bukti=khususd.no_bukti AND khusus.no_bukti=?";

                $insertSPOParams = [$no_bukti];

                Log::info('TOrderKoreksiPembelian Insert SPO:', [
                    'query' => $insertSPOQuery,
                    'params' => $insertSPOParams
                ]);

                DB::statement($insertSPOQuery, $insertSPOParams);

                $updatePostedQuery = "UPDATE khusus SET posted=1 WHERE no_bukti=?";
                $updatePostedParams = [$no_bukti];

                Log::info('TOrderKoreksiPembelian Update Posted Status:', [
                    'query' => $updatePostedQuery,
                    'params' => $updatePostedParams
                ]);

                DB::statement($updatePostedQuery, $updatePostedParams);
            }

            // Get print data
            $printDataQuery = "SELECT khusus.NO_BUKTI, khusus.per, khususd.kodes, khusus.namas, KHUSUS.notes, KHUSUS.FLAG,
                    KHUSUSd.total, KHUSUS.type, khusus.hari, KHUSUS.cbg, brg.ket_kem, khususd.NA_BRG,
                    khususd.KD_BRG, khususd.qty, khususd.harga, brg.mo, khususd.riil, khususd.qtybrg,
                    left(trim(khususd.kd_brg), 3) as sub, right(trim(khususd.kd_brg), 4) as kdbar,
                    khusus.ket, date(now()) as tgl, brg.ket_uk, khususd.kd_laku
             FROM khusus, khususd, brg
             WHERE khusus.no_bukti=khususd.no_bukti
               AND khususd.KD_BRG=brg.KD_BRG
               AND khusus.no_bukti=?";

            $printDataParams = [$no_bukti];

            Log::info('TOrderKoreksiPembelian Get Print Data:', [
                'query' => $printDataQuery,
                'params' => $printDataParams
            ]);

            $data = DB::select($printDataQuery, $printDataParams);

            Log::info('TOrderKoreksiPembelian Print Data Retrieved:', ['count' => count($data)]);

            return response()->json(['data' => $data]);
        } catch (\Exception $e) {
            Log::error('TOrderKoreksiPembelian Error in printOrderKoreksiPembelian: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal mencetak: ' . $e->getMessage()
            ], 500);
        }
    }

    private function generateNoBukti($periodeSession, $flag)
    {
        // Convert periode array to string format MM/YYYY if it's an array
        if (is_array($periodeSession)) {
            $monthString = str_pad($periodeSession['bulan'], 2, '0', STR_PAD_LEFT);
            $year = $periodeSession['tahun'];
        } else {
            // Fallback for old format MM.YYYY or MM/YYYY
            $monthString = substr($periodeSession, 0, 2);
            $year = substr($periodeSession, -4);
        }

        Log::info('TOrderKoreksiPembelian Generate NO_BUKTI:', [
            'month' => $monthString,
            'year' => $year,
            'flag' => $flag
        ]);

        $tokoQuery = "SELECT type FROM toko WHERE kode=?";
        $tokoParams = [$flag];

        Log::info('TOrderKoreksiPembelian Get Toko Type:', [
            'query' => $tokoQuery,
            'params' => $tokoParams
        ]);

        $toko = DB::select($tokoQuery, $tokoParams);
        $kode2 = $toko[0]->type ?? '';

        $kode = 'BL' . substr($year, -2) . $monthString;

        $notransQuery = "SELECT NOM{$monthString} as no_bukti FROM notrans WHERE trans='KHU' AND per=?";
        $notransParams = [$year];

        Log::info('TOrderKoreksiPembelian Get Notrans:', [
            'query' => $notransQuery,
            'params' => $notransParams
        ]);

        $notrans = DB::select($notransQuery, $notransParams);
        $r1 = ($notrans[0]->no_bukti ?? 0) + 1;

        $updateNotransQuery = "UPDATE notrans SET NOM{$monthString}=? WHERE trans='KHU' AND per=?";
        $updateNotransParams = [$r1, $year];

        Log::info('TOrderKoreksiPembelian Update Notrans:', [
            'query' => $updateNotransQuery,
            'params' => $updateNotransParams
        ]);

        DB::statement($updateNotransQuery, $updateNotransParams);

        $bkt1 = str_pad($r1, 4, '0', STR_PAD_LEFT);
        $generatedNoBukti = $kode . '-' . $bkt1 . $kode2;

        Log::info('TOrderKoreksiPembelian Generated NO_BUKTI:', ['no_bukti' => $generatedNoBukti]);

        return $generatedNoBukti;
    }
}
