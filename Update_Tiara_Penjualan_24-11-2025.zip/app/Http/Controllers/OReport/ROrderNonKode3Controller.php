<?php

namespace App\Http\Controllers\OReport;

use App\Http\Controllers\Controller;
use App\Models\Master\Cbg;
use App\Models\Master\Perid;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

include_once base_path() . "/vendor/simitgroup/phpjasperxml/version/1.1/PHPJasperXML.inc.php";

use PHPJasperXML;

class ROrderNonKode3Controller extends Controller
{
    public function report()
    {
        Log::info('Generating report for ROrderNonKode3');
        $cbg = Cbg::groupBy('CBG')->get();
        $per = Perid::query()->get();

        // Initialize session variables
        session()->put('filter_cbg', '');
        session()->put('filter_sub1', '');
        session()->put('filter_sub2', '');

        return view('oreport_ordernonkode3.report')->with([
            'cbg' => $cbg,
            'per' => $per,
            'hasilOrderNonKode3' => []
        ]);
    }

    public function getOrderNonKode3Report(Request $request)
    {
        $cbg = Cbg::groupBy('CBG')->get();
        $per = Perid::query()->get();

        // Set filter values to session
        session()->put('filter_cbg', $request->cbg ?? '');
        session()->put('filter_sub1', $request->sub1 ?? '');
        session()->put('filter_sub2', $request->sub2 ?? '');

        $hasilOrderNonKode3 = [];

        if (!empty($request->cbg) && !empty($request->sub1) && !empty($request->sub2)) {
            try {
                $hasilOrderNonKode3 = $this->getOrderNonKode3Data($request->cbg, $request->sub1, $request->sub2);
            } catch (\Exception $e) {
                Log::error('Error in getOrderNonKode3Report: ' . $e->getMessage());
                return view('oreport_ordernonkode3.report')->with([
                    'cbg' => $cbg,
                    'per' => $per,
                    'hasilOrderNonKode3' => [],
                    'error' => $e->getMessage()
                ]);
            }
        }

        return view('oreport_ordernonkode3.report')->with([
            'cbg' => $cbg,
            'per' => $per,
            'hasilOrderNonKode3' => $hasilOrderNonKode3
        ]);
    }

    /**
     * Get data Order Non-Kode sesuai filter cabang dan sub range
     * Implementasi dari logika Delphi
     */
    private function getOrderNonKode3Data($cbg, $sub1, $sub2)
    {
        try {
            // Validasi input
            $this->validateInput($cbg, $sub1, $sub2);

            // Get nama toko berdasarkan kode cabang
            $namaToko = $this->getNamaToko($cbg);

            if (empty($namaToko)) {
                throw new \Exception('Cabang tidak ditemukan atau tidak valid!');
            }

            $currentYear = date('Y');

            // Query utama berdasarkan logika Delphi - disesuaikan dengan struktur database Laravel
            $query = "
            SELECT
                :namaToko as NA_TOKO,
                :sub1 as SUB1,
                :sub2 as SUB2,
                rnonkode3.*,
                LEFT(rnonkode3.KD_BRG, 3) as SUB,
                CASE
                    WHEN rnonkode3.QTY_SP >= rnonkode3.DTR THEN 'OKE'
                    WHEN rnonkode3.QTY_SP > 0 THEN 'ON ORD'
                    WHEN CEILING(GREATEST(rnonkode3.SRMIN, rnonkode3.DTR_APF/2)) - rnonkode3.STOK < 3
                         AND rnonkode3.QTY_SP < 3 THEN 'ORD<3/BLM SR-'
                    WHEN rnonkode3.QTY_SP = 0 THEN 'TMO'
                    ELSE ''
                END as KETERANGAN
            FROM (
                SELECT
                    a.KD_BRG,
                    a.NA_BRG,
                    COALESCE(a.KET_UK, '') as KET_UK,
                    COALESCE(a.SUPP, '') as SUPP,
                    COALESCE(b.LPH, 0) as LPH,
                    COALESCE(c.DTR, 0) as DTR,
                    CASE
                        WHEN a.SUB IN ('031','108','137','143','145','146') THEN
                            ROUND(1.5 * COALESCE(b.LPH, 0) *
                            CASE
                                WHEN COALESCE(b.KLK, 0) > 10 THEN 10
                                ELSE GREATEST(COALESCE(b.KLK, 0), 1)
                            END, 2)
                        ELSE
                            ROUND(2.5 * COALESCE(b.LPH, 0) * 2, 2)
                    END as SRMIN,
                    COALESCE(c.DTR, 0) + COALESCE(c.DTR2, 0) as DTR_APF,
                    COALESCE(b.AK00, 0) + COALESCE(b.GAK00, 0) as STOK,
                    COALESCE((
                        SELECT SUM(COALESCE(y.qty, 0))
                        FROM {$cbg}.po x
                        INNER JOIN {$cbg}.pod y ON x.NO_BUKTI = y.NO_BUKTI
                        WHERE y.KD_BRG = a.KD_BRG
                        AND COALESCE(x.TYPE, '') != 'KS'
                        AND COALESCE(x.utuh, '') = 'U'
                        AND COALESCE(x.FLAG, '') IN ('PO','SP')
                    ), 0) as QTY_SP
                FROM {$cbg}.brg a
                INNER JOIN {$cbg}.brgdt b ON a.KD_BRG = b.KD_BRG
                LEFT JOIN {$cbg}.brg_dc_ts c ON b.KD_BRG = c.KD_BRG
                WHERE b.YER = :currentYear
                AND COALESCE(b.TD_OD, '') = ''
                AND LEFT(COALESCE(a.NA_BRG, ''), 1) NOT IN ('3','5','8')
                AND COALESCE(a.KET_KEM, '') != ''
                AND COALESCE(a.SUB, '000') NOT IN ('151','158')
                AND COALESCE(a.SUB, '000') BETWEEN :sub1 AND :sub2
                HAVING STOK <= CEILING(GREATEST(SRMIN, DTR_APF/2))
            ) as rnonkode3
            ORDER BY rnonkode3.KD_BRG ASC
            ";

            $hasilData = DB::select($query, [
                'namaToko' => $namaToko,
                'sub1' => $sub1,
                'sub2' => $sub2,
                'currentYear' => $currentYear
            ]);

            // Transform data sesuai format yang dibutuhkan untuk datatable
            $result = [];
            foreach ($hasilData as $item) {
                $result[] = [
                    'NA_TOKO' => $item->NA_TOKO ?? '',
                    'SUB1' => $item->SUB1 ?? '',
                    'SUB2' => $item->SUB2 ?? '',
                    'KD_BRG' => $item->KD_BRG ?? '', // Sub Item
                    'NA_BRG' => $item->NA_BRG ?? '', // Nama Barang
                    'KET_UK' => $item->KET_UK ?? '', // Ukuran
                    'SUPP' => $item->SUPP ?? '',
                    'LPH' => number_format($item->LPH ?? 0, 0), // LPH
                    'DTR' => number_format($item->DTR ?? 0, 0), // DTR
                    'SRMIN' => number_format($item->SRMIN ?? 0, 2), // SRMIN
                    'DTR_APF' => number_format($item->DTR_APF ?? 0, 0),
                    'STOK' => number_format($item->STOK ?? 0, 0), // Stok
                    'QTY_SP' => number_format($item->QTY_SP ?? 0, 0), // On SP
                    'SUB' => $item->SUB ?? '',
                    'KETERANGAN' => $item->KETERANGAN ?? '', // Keterangan
                    // Perhitungan tambahan untuk analisis
                    'THRESHOLD' => ceil(max($item->SRMIN ?? 0, ($item->DTR_APF ?? 0) / 2)),
                    'SELISIH_STOK' => ($item->STOK ?? 0) - ceil(max($item->SRMIN ?? 0, ($item->DTR_APF ?? 0) / 2))
                ];
            }

            // Log activity
            $this->logActivity('get_order_nonkode3', $cbg, "SUB: {$sub1}-{$sub2}", count($result));

            return $result;
        } catch (\Exception $e) {
            Log::error('Error in getOrderNonKode3Data: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Get nama toko berdasarkan kode cabang
     * Implementasi dari query Delphi: SELECT NAMA_TOKO from toko WHERE KODE=:cbg
     */
    private function getNamaToko($cbg)
    {
        try {
            $result = DB::table('tgz.toko')
                ->select('NAMA_TOKO')
                ->where('KODE', $cbg)
                ->whereIn('STA', ['MA', 'CB', 'DC']) // Pastikan toko aktif
                ->first();

            return $result ? $result->NAMA_TOKO : '';
        } catch (\Exception $e) {
            Log::error('Error in getNamaToko: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Get daftar cabang yang valid
     */
    public function getCabangList()
    {
        try {
            $query = "
            SELECT KODE, NAMA_TOKO as NAMA, STA
            FROM tgz.toko
            WHERE STA IN ('MA', 'CB', 'DC')
            ORDER BY NO_ID ASC
            ";

            return DB::select($query);
        } catch (\Exception $e) {
            Log::error('Error in getCabangList: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Validasi input parameters
     */
    private function validateInput($cbg, $sub1 = null, $sub2 = null)
    {
        if (empty($cbg)) {
            throw new \Exception('Cabang harus diisi!');
        }

        if ($sub1 !== null && empty($sub1)) {
            throw new \Exception('Entrian Sub (Dari) masih kosong..');
        }

        if ($sub2 !== null && empty($sub2)) {
            throw new \Exception('Entrian Sub (Sampai) masih kosong..');
        }

        // Validate cabang format
        if (!preg_match('/^[A-Z0-9]+$/', $cbg)) {
            throw new \Exception('Format cabang tidak valid!');
        }

        // Validate SUB format if provided
        if ($sub1 !== null && !preg_match('/^[0-9]{3}$/', $sub1)) {
            throw new \Exception('Format Sub (Dari) tidak valid! Harus 3 digit angka.');
        }

        if ($sub2 !== null && !preg_match('/^[0-9]{3}$/', $sub2)) {
            throw new \Exception('Format Sub (Sampai) tidak valid! Harus 3 digit angka.');
        }

        // Validate range SUB
        if ($sub1 !== null && $sub2 !== null && $sub1 > $sub2) {
            throw new \Exception('Sub (Dari) tidak boleh lebih besar dari Sub (Sampai)!');
        }

        // Validate cabang exists in toko table
        $cabangExists = DB::table('tgz.toko')
            ->where('KODE', $cbg)
            ->whereIn('STA', ['MA', 'CB', 'DC'])
            ->exists();

        if (!$cabangExists) {
            throw new \Exception('Cabang tidak valid atau tidak aktif!');
        }

        return true;
    }

    /**
     * Helper method untuk logging
     */
    private function logActivity($action, $cbg, $additionalInfo = '', $recordCount = 0)
    {
        Log::info("OrderNonKode3: {$action}", [
            'cbg' => $cbg,
            'additional_info' => $additionalInfo,
            'record_count' => $recordCount,
            'user' => auth()->user()->id ?? 'system',
            'timestamp' => now()
        ]);
    }

    /**
     * Generate Jasper Report
     */
    public function jasperOrderNonKode3Report(Request $request)
    {
        try {
            $cbg = $request->cbg ?? '';
            $sub1 = $request->sub1 ?? '';
            $sub2 = $request->sub2 ?? '';

            if (empty($cbg) || empty($sub1) || empty($sub2)) {
                return redirect()->back()->with('error', 'Parameter tidak lengkap untuk generate report!');
            }

            // Get data
            $data = $this->getOrderNonKode3Data($cbg, $sub1, $sub2);
            $namaToko = $this->getNamaToko($cbg);

            if (empty($data)) {
                return redirect()->back()->with('error', 'Tidak ada data untuk dicetak!');
            }

            // Prepare Jasper parameters
            $parameters = [
                'REPORT_TITLE' => 'LAPORAN ORDER NON-KODE 3',
                'COMPANY_NAME' => 'PT. SUMBER ALFARIA TRIJAYA',
                'CABANG' => $cbg,
                'NAMA_TOKO' => $namaToko,
                'SUB_DARI' => $sub1,
                'SUB_SAMPAI' => $sub2,
                'TANGGAL_CETAK' => date('d/m/Y H:i:s'),
                'USER_CETAK' => auth()->user()->name ?? 'System'
            ];

            // Generate report using PHPJasperXML
            $jasper = new PHPJasperXML();
            $jasper->load_xml_file(resource_path('jasper/ordernonkode3_report.jrxml'));

            // Set parameters
            $jasper->arrayParameter = $parameters;

            // Set data source
            $jasper->arraysqltable = $data;

            // Load and generate PDF
            $jasper->xml_dismantle();
            $jasper->outpage('pdf', 'Laporan_Order_NonKode3_' . $cbg . '_' . date('Ymd') . '.pdf');
        } catch (\Exception $e) {
            Log::error('Error in jasperOrderNonKode3Report: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Gagal generate report: ' . $e->getMessage());
        }
    }

    /**
     * Get summary statistics for dashboard
     */
    public function getSummaryStats($data)
    {
        if (empty($data)) {
            return [
                'total_items' => 0,
                'total_stok' => 0,
                'total_on_sp' => 0,
                'items_tmo' => 0,
                'items_oke' => 0,
                'items_on_ord' => 0
            ];
        }

        $stats = [
            'total_items' => count($data),
            'total_stok' => 0,
            'total_on_sp' => 0,
            'items_tmo' => 0,
            'items_oke' => 0,
            'items_on_ord' => 0
        ];

        foreach ($data as $item) {
            // Convert formatted numbers back to numeric for calculation
            $stok = (float) str_replace(',', '', $item['STOK']);
            $qtySp = (float) str_replace(',', '', $item['QTY_SP']);

            $stats['total_stok'] += $stok;
            $stats['total_on_sp'] += $qtySp;

            // Count by keterangan
            switch ($item['KETERANGAN']) {
                case 'TMO':
                    $stats['items_tmo']++;
                    break;
                case 'OKE':
                    $stats['items_oke']++;
                    break;
                case 'ON ORD':
                    $stats['items_on_ord']++;
                    break;
            }
        }

        return $stats;
    }
}