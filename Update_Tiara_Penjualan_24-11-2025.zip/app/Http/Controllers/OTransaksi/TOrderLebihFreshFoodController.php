<?php

namespace App\Http\Controllers\OTransaksi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Yajra\DataTables\Facades\DataTables;

class TOrderLebihFreshFoodController extends Controller
{
    public function index(Request $request)
    {
        try {
            $judul = 'Transaksi Order Lebih Fresh Food';

            $CBG = Auth::user()->CBG ?? null;
            $username = Auth::user()->username ?? 'system';

            if (!$CBG) {
                return view("otransaksi_TOrderLebihFreshFood.index")->with([
                    'judul' => $judul,
                    'error' => 'User tidak memiliki akses cabang (CBG). Hubungi administrator.'
                ]);
            }

            if (!$request->session()->has('periode')) {
                return view("otransaksi_TOrderLebihFreshFood.index")->with([
                    'judul' => $judul,
                    'warning' => 'Periode belum diset. Silakan set periode terlebih dahulu.'
                ]);
            }

            $periode = $request->session()->get('periode');

            return view("otransaksi_TOrderLebihFreshFood.index")->with([
                'judul' => $judul,
                'cbg' => $CBG,
                'periode' => $periode,
                'username' => $username
            ]);
        } catch (\Exception $e) {
            Log::error('Error in TOrderLebihFreshFood index: ' . $e->getMessage());
            return view("otransaksi_TOrderLebihFreshFood.index")->with([
                'judul' => 'Transaksi Order Lebih Fresh Food',
                'error' => 'Terjadi kesalahan: ' . $e->getMessage()
            ]);
        }
    }

    // Ambil data untuk datatables
    public function cari_data(Request $request)
    {
        try {
            $CBG = Auth::user()->CBG ?? null;
            $username = Auth::user()->username ?? 'system';
            $connection = strtolower($CBG);

            if (!$CBG) {
                return response()->json(['error' => 'User tidak memiliki akses cabang'], 400);
            }

            Log::info('TOrderLebihFreshFood cari_data', [
                'CBG' => $CBG,
                'connection' => $connection,
                'username' => $username
            ]);

            $periode = $request->session()->get('periode');
            if (!$periode) {
                return response()->json(['error' => 'Periode belum diset'], 400);
            }

            // Query untuk menampilkan data order lebih (FLAG='OL')
            $query = "
                SELECT 
                    o.rec,
                    o.SUB,
                    o.KDBAR,
                    o.KD_BRG,
                    o.NA_BRG,
                    o.KET_KEM,
                    o.QTY,
                    o.KODES as SUPP,
                    DATE_FORMAT(o.TGL, '%d-%m-%Y') as TGL_KIRIM,
                    o.TGL as TGL_RAW,
                    ? as USER
                FROM orderts o
                WHERE o.flag = 'OL' 
                AND o.cbg = ?
                ORDER BY o.KD_BRG ASC
            ";

            $data = DB::connection($connection)->select($query, [$username, $CBG]);

            Log::info('TOrderLebihFreshFood cari_data - raw_query_untuk_navicat', [
                'query' => str_replace(['?', '?'], ["'$username'", "'$CBG'"], $query)
            ]);

            return Datatables::of(collect($data))
                ->addIndexColumn()
                ->editColumn('QTY', function ($row) {
                    return number_format($row->QTY, 2, ',', '.');
                })
                ->addColumn('action', function ($row) {
                    return '<button class="btn btn-sm btn-danger btn-delete-item" data-rec="' . $row->rec . '" title="Hapus Item">
                                <i class="fas fa-trash"></i>
                            </button>';
                })
                ->rawColumns(['action'])
                ->make(true);
        } catch (\Exception $e) {
            Log::error('Error in cari_data: ' . $e->getMessage());
            return response()->json(['error' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
        }
    }

    // Lookup barang - popup daftar barang kode 3 (fresh food)
    public function lookup_barang(Request $request)
    {
        try {
            $CBG = Auth::user()->CBG ?? null;
            $connection = strtolower($CBG);

            if (!$CBG) {
                return response()->json(['error' => 'User tidak memiliki akses cabang'], 400);
            }

            Log::info('TOrderLebihFreshFood lookup_barang', [
                'CBG' => $CBG,
                'connection' => $connection
            ]);

            // Query untuk barang dengan klk = '3' (fresh food kode 3)
            $query = "
                SELECT 
                    kd_brg,
                    na_brg,
                    ket_uk,
                    ket_kem,
                    satuan,
                    klk
                FROM brg
                WHERE klk = '3'
                ORDER BY kd_brg ASC
                LIMIT 1000
            ";

            $data = DB::connection($connection)->select($query);

            Log::info('TOrderLebihFreshFood lookup_barang - raw_query_untuk_navicat', [
                'query' => $query,
                'result_count' => count($data)
            ]);

            return response()->json([
                'success' => true,
                'data' => $data
            ]);
        } catch (\Exception $e) {
            Log::error('Error in lookup_barang: ' . $e->getMessage());
            return response()->json(['error' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
        }
    }

    // Proses untuk berbagai action
    public function proses(Request $request)
    {
        try {
            $CBG = Auth::user()->CBG ?? null;
            $username = Auth::user()->username ?? 'system';
            $connection = strtolower($CBG);

            if (!$CBG) {
                return response()->json(['error' => 'User tidak memiliki akses cabang'], 400);
            }

            Log::info('TOrderLebihFreshFood proses', [
                'CBG' => $CBG,
                'connection' => $connection,
                'action' => $request->input('action')
            ]);

            $action = $request->input('action', '');

            DB::connection($connection)->beginTransaction();

            switch ($action) {
                case 'save':
                    return $this->saveOrder($request, $CBG, $username);

                case 'refresh':
                    return $this->refreshData($request, $CBG);

                case 'delete_item':
                    return $this->deleteItem($request, $CBG);

                case 'delete_all':
                    return $this->deleteAll($request, $CBG);

                case 'print':
                    return $this->printOrder($request, $CBG, $username);

                case 'export_excel':
                    return $this->exportExcel($request, $CBG, $username);

                default:
                    DB::connection($connection)->rollBack();
                    return response()->json(['error' => 'Action tidak valid'], 400);
            }
        } catch (\Exception $e) {
            if ($CBG) {
                DB::connection(strtolower($CBG))->rollBack();
            }
            Log::error('Error in proses: ' . $e->getMessage());
            return response()->json([
                'error' => 'Proses gagal: ' . $e->getMessage()
            ], 500);
        }
    }

    private function saveOrder($request, $CBG, $username)
    {
        $connection = strtolower($CBG);
        $kd_brg = trim($request->input('kd_brg', ''));
        $qty = $request->input('qty', 0);

        if (empty($kd_brg)) {
            DB::connection($connection)->rollBack();
            return response()->json(['error' => 'Kode barang tidak boleh kosong'], 400);
        }

        // Cek apakah barang ada di master
        $barang = DB::connection($connection)->selectOne("
            SELECT 
                sub,
                kdbar,
                KD_BRG,
                CONCAT(na_brg, ' ', ket_uk) as na_brg,
                ket_kem,
                supp
            FROM brg 
            WHERE KD_BRG = ?
        ", [$kd_brg]);

        if (!$barang) {
            DB::connection($connection)->rollBack();
            return response()->json(['error' => 'Kode barang tidak ditemukan'], 404);
        }

        // Cek apakah sudah ada di orderts dengan FLAG='OL'
        $existing = DB::connection($connection)->selectOne("
            SELECT rec 
            FROM orderts 
            WHERE KD_BRG = ? 
            AND flag = 'OL' 
            AND cbg = ?
        ", [$kd_brg, $CBG]);

        if ($existing) {
            DB::connection($connection)->rollBack();
            return response()->json(['error' => 'Barang sudah ada dalam daftar order'], 400);
        }

        // Insert ke orderts
        DB::connection($connection)->statement("
            INSERT INTO orderts (
                SUB, KDBAR, KD_BRG, NA_BRG, KET_KEM, QTY, KODES, TGL, FLAG, CBG
            ) VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE(), 'OL', ?)
        ", [
            $barang->sub,
            $barang->kdbar,
            $barang->KD_BRG,
            $barang->na_brg,
            $barang->ket_kem,
            $qty,
            $barang->supp,
            $CBG
        ]);

        DB::connection($connection)->commit();

        return response()->json([
            'success' => true,
            'message' => 'Data berhasil ditambahkan!'
        ]);
    }

    private function refreshData($request, $CBG)
    {
        $connection = strtolower($CBG);
        DB::connection($connection)->commit();

        return response()->json([
            'success' => true,
            'message' => 'Data berhasil direfresh!'
        ]);
    }

    private function deleteItem($request, $CBG)
    {
        $connection = strtolower($CBG);
        $rec = $request->input('rec');

        if (!$rec) {
            DB::connection($connection)->rollBack();
            return response()->json(['error' => 'Record tidak ditemukan'], 400);
        }

        DB::connection($connection)->statement("
            DELETE FROM orderts 
            WHERE rec = ? AND cbg = ? AND flag = 'OL'
        ", [$rec, $CBG]);

        DB::connection($connection)->commit();

        return response()->json([
            'success' => true,
            'message' => 'Item berhasil dihapus!'
        ]);
    }

    private function deleteAll($request, $CBG)
    {
        $connection = strtolower($CBG);
        DB::connection($connection)->statement("
            DELETE FROM orderts 
            WHERE cbg = ? AND flag = 'OL'
        ", [$CBG]);

        DB::connection($connection)->commit();

        return response()->json([
            'success' => true,
            'message' => 'Semua data berhasil dihapus!'
        ]);
    }

    private function printOrder($request, $CBG, $username)
    {
        $connection = strtolower($CBG);
        // Get data untuk print
        $data = DB::connection($connection)->select("
            SELECT 
                ? AS USER,
                o.rec,
                o.SUB,
                o.KDBAR,
                o.KD_BRG,
                o.NA_BRG,
                o.KET_KEM,
                o.QTY,
                o.KODES as SUPP,
                DATE_FORMAT(o.TGL, '%d-%m-%Y') as TGL_KIRIM
            FROM orderts o
            WHERE o.flag = 'OL' 
            AND o.cbg = ?
            ORDER BY o.KD_BRG ASC
        ", [$username, $CBG]);

        if (empty($data)) {
            DB::connection($connection)->rollBack();
            return response()->json(['error' => 'Tidak ada data untuk dicetak'], 404);
        }

        DB::connection($connection)->commit();

        return response()->json([
            'success' => true,
            'data' => $data
        ]);
    }

    private function exportExcel($request, $CBG, $username)
    {
        $connection = strtolower($CBG);
        // Get data untuk export excel
        $data = DB::connection($connection)->select("
            SELECT 
                o.SUB as 'Sub Item',
                o.KDBAR as 'Kode Barang',
                o.KD_BRG as 'Kode BRG',
                o.NA_BRG as 'Nama Barang',
                o.KET_KEM as 'Kemasan',
                o.QTY as 'Qty',
                o.KODES as 'SUPP',
                DATE_FORMAT(o.TGL, '%d-%m-%Y') as 'Tgl Kirim'
            FROM orderts o
            WHERE o.flag = 'OL' 
            AND o.cbg = ?
            ORDER BY o.KD_BRG ASC
        ", [$CBG]);

        if (empty($data)) {
            DB::connection($connection)->rollBack();
            return response()->json(['error' => 'Tidak ada data untuk di-export'], 404);
        }

        DB::connection($connection)->commit();

        return response()->json([
            'success' => true,
            'data' => $data
        ]);
    }
}
